$ErrorActionPreference = 'Stop'
$root = (Get-Location).Path
$expectedBranch = 'release/campaignos-development-preview-20261104'
$paths = @('src/supporterAuth.ts','src/components/CampaignInlineAuthPanel.tsx','src/pages/VoiceupLoginPage.tsx')
$backup = Join-Path $root ('.gsaa-email-otp-rollback-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
$report = New-Object System.Collections.Generic.List[string]
$changed = $false
try {
  if ((git branch --show-current) -ne $expectedBranch) { throw 'STOP: wrong branch' }
  if (-not (Test-Path 'package.json')) { throw 'STOP: run from the GSAA Development repository root' }
  $expected = Get-Content (Join-Path $PSScriptRoot 'expected-sha256.json') -Raw | ConvertFrom-Json
  foreach ($relative in $paths) {
    $target = Join-Path $root ($relative.Replace('/','\'))
    $source = Join-Path $PSScriptRoot ($relative.Replace('/','\'))
    if (-not (Test-Path $target)) { throw "STOP: missing $relative" }
    if (-not (Test-Path $source)) { throw "STOP: missing patch $relative" }
    $actual = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -ne $expected.$relative) { throw "STOP: $relative changed since the uploaded snapshot; no files modified" }
  }
  foreach ($relative in $paths) {
    $target = Join-Path $root ($relative.Replace('/','\'))
    $save = Join-Path $backup ($relative.Replace('/','\'))
    New-Item -ItemType Directory -Force -Path (Split-Path $save -Parent) | Out-Null
    Copy-Item -LiteralPath $target -Destination $save
  }
  foreach ($relative in $paths) {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot ($relative.Replace('/','\'))) -Destination (Join-Path $root ($relative.Replace('/','\'))) -Force
  }
  $changed = $true
  $report.Add('PATCH APPLIED TO DEVELOPMENT WORKTREE')
  & npm run build 2>&1 | ForEach-Object { $report.Add("$_"); Write-Host $_ }
  if ($LASTEXITCODE -ne 0) { throw 'BUILD FAILED' }
  & node --test tests/campaignContextualLogin.test.mjs 2>&1 | ForEach-Object { $report.Add("$_"); Write-Host $_ }
  if ($LASTEXITCODE -ne 0) { throw 'REGRESSION TEST FAILED' }
  $report.Add('PASS: Build and campaign authentication regression test')
  $report.Add("ROLLBACK BACKUP: $backup")
} catch {
  $report.Add("STOP: $($_.Exception.Message)")
  if ($changed) {
    foreach ($relative in $paths) {
      $save = Join-Path $backup ($relative.Replace('/','\'))
      if (Test-Path $save) { Copy-Item -LiteralPath $save -Destination (Join-Path $root ($relative.Replace('/','\'))) -Force }
    }
    $report.Add('ROLLBACK: original files restored')
  }
} finally {
  $text = $report -join [Environment]::NewLine
  try { $text | Set-Clipboard } catch {}
  Write-Host $text
}
