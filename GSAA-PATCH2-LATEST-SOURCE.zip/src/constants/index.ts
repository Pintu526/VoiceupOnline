import type { Campaign } from "../types";

export const storagePrefix = "voiceup-world-class-campaigns-v4";

export const categories: Campaign["category"][] = [
  "Civic",
  "Environment",
  "Education",
  "Health",
  "Transport",
  "Housing",
  "Other"
];

export const emptyMetrics = {
  total: 0,
  verified: 0,
  pending: 0,
  duplicates: 0,
  online: 0,
  scanned: 0,
  progress: 0
};

export const blankSigner = {
  name: "",
  email: "",
  phone: "",
  whatsappNumber: "",
  telegramHandle: "",
  otpVerified: false,
  verificationMethod: undefined as "phone_otp" | "email_otp" | "screen_otp" | undefined,
  phoneOwnershipVerified: false,
  emailOwnershipVerified: false,
  otpChallengeId: "",
  otpVerificationToken: "",
  selectedAuthorityId: "",
  selectedAuthorityName: "",
  country: "",
  state: "",
  district: "",
  block: "",
  panchayat: "",
  address: "",
  postalCode: "",
  locationReference: null as PersistedLocationReference | null,
  comment: "",
  referralCode: "",
  referredBy: "",
  referredByPhoneOrCode: "",
  referralSource: undefined as "url" | "manual" | undefined
};

export const blankAdminLogin = {
  email: "",
  passcode: ""
};

export const blankAppLogin = {
  email: "",
  passcode: ""
};

export const blankScanTemplate = `Name:
Email:
Phone:
Country:
State:
District:
Block:
Gram Panchayat:
Address:
PIN Code:
Comment:`;
import type { PersistedLocationReference } from "../businessOs/location/persistence/PersistedLocationReference.ts";
