import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import {
  ArrowRight,
  BadgeCheck,
  CalendarDays,
  CheckCircle2,
  ClipboardList,
  Copy,
  HeartHandshake,
  Landmark,
  LockKeyhole,
  LogIn,
  Mail,
  MapPin,
  MessageCircle,
  QrCode,
  Share2,
  ShieldCheck,
  Smartphone,
  UserRound,
  Users,
  Volume2,
  VolumeX
} from "lucide-react";
import type {
  AuthorityRule,
  Campaign,
  Organization,
  ParticipationRequestLevel,
  ParticipationRequestSubmission,
  PublicParticipationRequest,
  Signer,
  SignerRequiredField
} from "../types";
import { getConfiguredGrowthShareMessages } from "../growth/configuration";
import type { GrowthShareContext, GrowthSupporterSnapshot } from "../growth/lifecycle";
import type { SupporterGrowthPortalModel } from "../growth/tree";
import type {
  LocationDeletions,
  LocationOverrides,
  LocationWithPin
} from "../geography";
import type { getCampaignMetrics } from "../lib";
import { Panel } from "../ui/Panel";
import { Field } from "../ui/Field";
import { DonationCard } from "../components/DonationCard";
import { IndiaLocationFields } from "../components/IndiaLocationFields";
import { resolveIndiaLocationCatalog } from "../components/indiaLocationOptions";
import { usePublicCampaignLocationCatalog } from "../components/usePublicCampaignLocationCatalog";
import { GlobalLocationFields } from "../components/GlobalLocationFields";
import { ReferralQrPreview } from "../components/ReferralQrPreview";
import { VoiceUpStoryCarousel } from "../components/VoiceUpStoryCarousel";
import { GauSammanApprovedContent } from "../components/GauSammanApprovedContent";
import { PublicCampaignCanonicalLocationDisplay } from "../businessOs/location/ui";
import {
  createObservedLocationReference,
  createUnverifiedLocationReference
} from "../businessOs/location/persistence/LocationReferenceGovernance.ts";
import type { PersistedLocationReference } from "../businessOs/location/persistence/PersistedLocationReference.ts";
import {
  PublicSupporterPhoto,
  type PublicSupporterPhotoCopy
} from "../components/PublicSupporterPhoto";
import { SupporterAccountClaimPanel } from "../components/SupporterAccountClaimPanel";
import { CampaignInlineAuthPanel } from "../components/CampaignInlineAuthPanel";
import type {
  SupporterAccountClaimGrant,
  SupporterAccountLink
} from "../supporterAccountClaim";
import { getCampaignLoginPath } from "../campaignAuthContext";
import { blankSigner } from "../constants";
import {
  isGaumataPublicHostname,
  isGoudhanProductionCampaign
} from "../config/goudhanProduction";
import {
  INDIAN_MOBILE_INPUT_MAX_LENGTH,
  getPublicCampaignPresentation,
  getPublicCampaignPresentationCopy,
  getSafeOtpDisplayMessage,
  getVisiblePublicMetrics,
  normalizeIndianMobileInput,
  sanitizePublicCampaignMediaUrl
} from "../config/publicCampaignPresentation";
import { LanguageSwitcher, useTranslation, type Language } from "../i18n";
import {
  getAppealAuthority,
  getAuthorityOptionsForCampaign,
  getConfiguredAppealAuthority,
  getPublicAuthorityOptions,
  formatAuthorityDisplay
} from "../utils/authority";
import {
  applySignerLocationRestriction,
  formatLocationForCampaign,
  getCampaignGoalValue,
  getCampaignGeographyMode,
  getCampaignLocationLabels,
  getCampaignPublicUrl,
  getCampaignScope,
  getEffectiveSignerLocationRestrictionLevel,
  getLocationRestrictionMessage,
  getLockedLocationValues,
  renderCampaignMessage
} from "../utils/campaign";
import {
  downloadQrPosterSvg,
  findReferrer,
  getCampaignReferralUrl,
  getSafeReferrerLabel,
  getPersistedSupporterReferralCode,
  normalizeReferralCode
} from "../utils/referrals";
import {
  clearPublicSigningJourney,
  clearPublicSigningOtpState,
  getPublicSigningJourneyStorageKey,
  isValidPublicSignerEmail,
  readPublicSigningDraft,
  type PublicSigningStepId,
  type PublicSigningVerificationOutcome,
  writePublicSigningDraft
} from "../publicSigningJourney";
import { createConsentVersion } from "../utils/consent";
import {
  PARTICIPATION_REQUEST_LEVELS,
  createParticipationRequestIdempotencyKey,
  getMinimumParticipationLevels,
  parseParticipationRequestList,
  participationRequestFingerprint
} from "../movementRequests";
import "../publicSigningExperience.css";
import {
  invokePublicCampaignLocationCatalog,
  type PublicCampaignCustomLocation
} from "../backend";
import {
  clearSupporterRoutingPrecheck,
  precheckPublicSupporterRouting,
  readSupporterRoutingPrecheck,
  writeSupporterRoutingPrecheck,
  type PublicSupporterRoutingPrecheck
} from "../supporterRouting";

interface PublicCampaignPageProps {
  campaign: Campaign;
  organization?: Organization;
  metrics: ReturnType<typeof getCampaignMetrics>;
  authority?: AuthorityRule;
  authorities: AuthorityRule[];
  campaignSigners: Signer[];
  publicForm: typeof blankSigner;
  setPublicForm: React.Dispatch<React.SetStateAction<typeof blankSigner>>;
  publicMessage: string;
  lastSignedSigner: Signer | null;
  supporterAccountClaimGrant?: SupporterAccountClaimGrant | null;
  linkedSupporterAccount?: SupporterAccountLink | null;
  onSupporterAccountLinked?: (link: SupporterAccountLink) => void;
  growthSnapshot?: GrowthSupporterSnapshot;
  growthPortal?: SupporterGrowthPortalModel;
  otpInput: string;
  setOtpInput: React.Dispatch<React.SetStateAction<string>>;
  otpMessage: string;
  onSendOtp: () => void | boolean | Promise<void | boolean>;
  onVerifyOtp: () => PublicSigningVerificationOutcome | Promise<PublicSigningVerificationOutcome>;
  onRetryVerifiedSupporterLookup?: () =>
    PublicSigningVerificationOutcome | Promise<PublicSigningVerificationOutcome>;
  locationOverrides: LocationOverrides;
  locationDeletions: LocationDeletions;
  customLocations?: PublicCampaignCustomLocation[];
  onGrowthShare?: (share: GrowthShareContext) => void;
  onUploadSupporterPhoto?: (file: File) => Promise<void>;
  onSaveDraft?: () => void | Promise<void>;
  onCommunicationConsentChange?: (granted: boolean) => void | Promise<void>;
  onSubmitMovementRequest?: (
    request: ParticipationRequestSubmission,
    idempotencyKey: string
  ) => Promise<PublicParticipationRequest>;
  movementRequests?: PublicParticipationRequest[];
  movementRequestsLoading?: boolean;
  movementRequestsError?: string;
  onRefreshMovementRequests?: () => void | Promise<void>;
  onSubmitCoordinatorApplication?: () => void | Promise<void>;
  onStartNewJourney: () => void;
  onSubmit: (event: FormEvent) => void | Promise<void>;
}

type SigningStepId = PublicSigningStepId;
type InvolvementPanel = "none" | "volunteer" | "coordinator";

const signingSteps: Array<{ id: SigningStepId }> = [
  { id: "phone" },
  { id: "otp" },
  { id: "profile" },
  { id: "address" },
  { id: "review" },
  { id: "done" }
];

function isPublicFailureMessage(message: string) {
  return (
    /\([a-z][a-z0-9_]{1,63}\)\s*$/i.test(message) ||
    /\b(could not|failed|failure|expired|invalid|unavailable|required|outside|retry|error|blocked|has ended|past due|cancelled|not active|not currently open|reached its|reached the)\b/i.test(message) ||
    /^(create and publish|enter |request |please verify|verify your)/i.test(message)
  );
}

const participationRequestErrorCodes = new Set([
  "invalid_request_payload",
  "invalid_request_type",
  "invalid_coordinator_level",
  "invalid_minimum_level",
  "incomplete_request_geography",
  "request_consent_required",
  "support_completion_required",
  "otp_verification_required",
  "active_participation_request_exists",
  "busy"
]);

function participationRequestErrorCode(error: unknown): string {
  if (!error || typeof error !== "object" || !("code" in error)) return "";
  const code = String((error as { code?: string }).code ?? "");
  return participationRequestErrorCodes.has(code) ? code : "";
}

function formatParticipationRequestGeography(request: PublicParticipationRequest): string {
  return [
    request.geographicScope.country,
    request.geographicScope.state,
    request.geographicScope.district,
    request.geographicScope.block,
    request.geographicScope.panchayat,
    request.geographicScope.ward
  ].filter(Boolean).join(", ");
}

function getYouTubeEmbedUrl(value: string): string {
  if (!value.trim()) return "";
  try {
    const url = new URL(value);
    const hostname = url.hostname.toLowerCase().replace(/^www\./, "");
    const videoId =
      hostname === "youtu.be"
        ? url.pathname.split("/").filter(Boolean)[0] ?? ""
        : hostname === "youtube.com" || hostname === "m.youtube.com"
          ? url.pathname.startsWith("/shorts/")
            ? url.pathname.split("/")[2] ?? ""
            : url.searchParams.get("v") ?? ""
          : "";
    return /^[a-zA-Z0-9_-]{6,20}$/.test(videoId)
      ? `https://www.youtube-nocookie.com/embed/${videoId}`
      : "";
  } catch {
    return "";
  }
}

const publicSigningCopyEn = {
  steps: {
    phone: "Phone",
    otp: "Verify",
    profile: "Profile",
    address: "Details",
    review: "Review",
    done: "Done"
  },
  panelTitleComplete: "Signature complete",
  panelTitleSign: "Sign this campaign",
  secureSigning: "Secure signing",
  headerComplete: "Thank you for adding your voice.",
  headerActive: "Sign in about 60 seconds.",
  headerHelp: "Only required fields are shown first. Optional details stay available when needed.",
  invitedBy: "You were invited by",
  invitedFallback: "a campaign supporter",
  referralOptional: "Referral is optional and never affects your ability to sign.",
  phoneVerifiedBody: "Continue to sign, review your details, or share the campaign.",
  viewSignature: "View signature",
  referFriends: "Refer friends",
  phoneTitle: "Start with your phone",
  phoneHelp: "A six-digit code will appear on the next screen to protect this signing journey from automated submissions.",
  requestVerification: "Continue to verification",
  otpTitle: "Complete verification",
  otpHelp: "Enter the code shown below. This verifies the signing journey, not ownership of the mobile number.",
  verifyCode: "Verify",
  verificationProtected: "Verification-protected participation",
  resendOtp: "Get a new code",
  phoneVerified: "Verification complete",
  verificationCompleteBody: "Signing verification is complete. Mobile number and email ownership were not verified.",
  profileTitle: "Your signature profile",
  profileHelp: "Enter the required signer details.",
  emailLabel: "Email",
  emailPlaceholder: "Email",
  authorityLabel: "Choose authority for your appeal",
  addOptionalDetails: "Add optional details",
  detailsTitle: "Required location and optional details",
  detailsHelp: "Location helps the campaign show where public support is coming from.",
  locationLimitTitle: "This campaign is limited to",
  addressLabel: "Address",
  addressPlaceholder: "House, street, locality",
  optionalDetails: "Contact and referral options",
  whatsappLabel: "WhatsApp number",
  whatsappPlaceholder: "If different from phone",
  telegramLabel: "Telegram handle or number",
  telegramPlaceholder: "@handle or number",
  referralLabel: "Referred by phone, name, or referral code",
  referralHelp: "Use a referrer phone, name, or code if someone invited you.",
  reviewTitle: "Review and sign",
  reviewHelp: "Confirm your support and submit your signature to this campaign.",
  reviewAuthority: "Authority",
  reviewReferral: "Referral",
  notEntered: "Not entered",
  none: "None",
  trustLabel: "Trust and privacy",
  privacyRespected: "Privacy respected",
  storedSecurely: "Stored securely only after successful submission",
  routedAuthority: "Prepared for the selected authority; delivery is not yet claimed",
  supportCheckbox: "I have read and support the campaign appeal/cause shown above.",
  consentRequiredInline: "Please review and accept both consent confirmations before signing.",
  doneBody: "Your voice has been recorded. Share this campaign to help it reach the next supporter.",
  locationLabels: {
    country: "Country",
    state: "State / Union Territory",
    district: "District",
    block: "Block / Tehsil / Taluk",
    panchayat: "Gram Panchayat / Ward",
    postalCode: "PIN / Postal Code"
  }
};

const publicSigningCopy: Record<Language, typeof publicSigningCopyEn> = {
  en: publicSigningCopyEn,
  hi: {
    steps: {
      phone: "फोन",
      otp: "सत्यापन",
      profile: "प्रोफाइल",
      address: "विवरण",
      review: "समीक्षा",
      done: "पूर्ण"
    },
    panelTitleComplete: "हस्ताक्षर पूर्ण",
    panelTitleSign: "इस अभियान पर हस्ताक्षर करें",
    secureSigning: "सुरक्षित हस्ताक्षर",
    headerComplete: "अपनी आवाज जोड़ने के लिए धन्यवाद।",
    headerActive: "लगभग 60 सेकंड में हस्ताक्षर करें।",
    headerHelp: "पहले केवल जरूरी जानकारी दिखाई जाती है। वैकल्पिक विवरण जरूरत पड़ने पर उपलब्ध हैं।",
    invitedBy: "आपको आमंत्रित किया",
    invitedFallback: "एक अभियान समर्थक",
    referralOptional: "रेफ़रल वैकल्पिक है और हस्ताक्षर करने की क्षमता को प्रभावित नहीं करता।",
    phoneVerifiedBody: "हस्ताक्षर जारी रखें, विवरण देखें, या अभियान साझा करें।",
    viewSignature: "हस्ताक्षर देखें",
    referFriends: "मित्रों को भेजें",
    phoneTitle: "अपने फोन से शुरू करें",
    phoneHelp: "स्वचालित प्रस्तुतियों से बचाने के लिए अगली स्क्रीन पर छह अंकों का कोड दिखेगा।",
    requestVerification: "सत्यापन के लिए आगे बढ़ें",
    otpTitle: "सत्यापन पूरा करें",
    otpHelp: "नीचे दिखाया गया कोड दर्ज करें। यह हस्ताक्षर यात्रा को सत्यापित करता है, मोबाइल नंबर के स्वामित्व को नहीं।",
    verifyCode: "सत्यापित करें",
    verificationProtected: "सत्यापन-सुरक्षित भागीदारी",
    resendOtp: "नया कोड लें",
    phoneVerified: "सत्यापन पूरा हुआ",
    verificationCompleteBody: "हस्ताक्षर सत्यापन पूरा हुआ। मोबाइल नंबर और ईमेल के स्वामित्व का सत्यापन नहीं किया गया।",
    profileTitle: "आपका हस्ताक्षर प्रोफाइल",
    profileHelp: "जरूरी समर्थक विवरण दर्ज करें।",
    emailLabel: "ईमेल",
    emailPlaceholder: "ईमेल",
    authorityLabel: "अपील के लिए अधिकारी चुनें",
    addOptionalDetails: "वैकल्पिक विवरण जोड़ें",
    detailsTitle: "जरूरी स्थान और वैकल्पिक विवरण",
    detailsHelp: "स्थान से अभियान को सार्वजनिक समर्थन का क्षेत्र दिखाने में मदद मिलती है।",
    locationLimitTitle: "यह अभियान सीमित है",
    addressLabel: "पता",
    addressPlaceholder: "घर, सड़क, मोहल्ला",
    optionalDetails: "संपर्क और रेफ़रल विकल्प",
    whatsappLabel: "WhatsApp नंबर",
    whatsappPlaceholder: "यदि फोन से अलग है",
    telegramLabel: "Telegram हैंडल या नंबर",
    telegramPlaceholder: "@handle या नंबर",
    referralLabel: "रेफ़र करने वाले का फोन, नाम, या कोड",
    referralHelp: "यदि किसी ने आमंत्रित किया है तो फोन, नाम, या कोड दर्ज करें।",
    reviewTitle: "समीक्षा करें और हस्ताक्षर करें",
    reviewHelp: "अपना समर्थन पुष्टि करें और हस्ताक्षर जमा करें।",
    reviewAuthority: "अधिकारी",
    reviewReferral: "रेफ़रल",
    notEntered: "दर्ज नहीं",
    none: "कोई नहीं",
    trustLabel: "विश्वास और गोपनीयता",
    privacyRespected: "गोपनीयता का सम्मान",
    storedSecurely: "सफल सबमिशन के बाद ही सुरक्षित रूप से संग्रहीत होगा",
    routedAuthority: "चुने गए अधिकारी के लिए तैयार; अभी भेजे जाने का दावा नहीं",
    supportCheckbox: "मैंने ऊपर दिखाए गए अभियान अपील/कारण को पढ़ा है और समर्थन करता/करती हूं।",
    consentRequiredInline: "हस्ताक्षर करने से पहले दोनों सहमति पुष्टिकरण स्वीकार करें।",
    doneBody: "आपकी आवाज दर्ज हो गई है। अगले समर्थक तक पहुंचने के लिए अभियान साझा करें।",
    locationLabels: {
      country: "देश",
      state: "राज्य / केंद्र शासित प्रदेश",
      district: "जिला",
      block: "ब्लॉक / तहसील / तालुक",
      panchayat: "ग्राम पंचायत / वार्ड",
      postalCode: "PIN / पोस्टल कोड"
    }
  },
  or: {
    steps: {
      phone: "ଫୋନ",
      otp: "ଯାଞ୍ଚ",
      profile: "ପ୍ରୋଫାଇଲ",
      address: "ବିବରଣୀ",
      review: "ସମୀକ୍ଷା",
      done: "ସମ୍ପୂର୍ଣ୍ଣ"
    },
    panelTitleComplete: "ସହି ସମ୍ପୂର୍ଣ୍ଣ",
    panelTitleSign: "ଏହି ଅଭିଯାନରେ ସହି କରନ୍ତୁ",
    secureSigning: "ସୁରକ୍ଷିତ ସହି",
    headerComplete: "ଆପଣଙ୍କ ଆବାଜ ଯୋଡିଥିବାରୁ ଧନ୍ୟବାଦ।",
    headerActive: "ପ୍ରାୟ 60 ସେକେଣ୍ଡରେ ସହି କରନ୍ତୁ।",
    headerHelp: "ପ୍ରଥମେ କେବଳ ଆବଶ୍ୟକ ତଥ୍ୟ ଦେଖାଯାଏ। ବୈକଳ୍ପିକ ବିବରଣୀ ଆବଶ୍ୟକ ହେଲେ ଉପଲବ୍ଧ ରହେ।",
    invitedBy: "ଆପଣଙ୍କୁ ଆମନ୍ତ୍ରଣ କରିଛନ୍ତି",
    invitedFallback: "ଏକ ଅଭିଯାନ ସମର୍ଥକ",
    referralOptional: "ରେଫରାଲ ବୈକଳ୍ପିକ ଏବଂ ସହି କରିବାକୁ ପ୍ରଭାବିତ କରେ ନାହିଁ।",
    phoneVerifiedBody: "ସହି ଜାରି ରଖନ୍ତୁ, ବିବରଣୀ ଦେଖନ୍ତୁ, କିମ୍ବା ଅଭିଯାନ ସେୟାର କରନ୍ତୁ।",
    viewSignature: "ସହି ଦେଖନ୍ତୁ",
    referFriends: "ମିତ୍ରଙ୍କୁ ପଠାନ୍ତୁ",
    phoneTitle: "ଆପଣଙ୍କ ଫୋନରୁ ଆରମ୍ଭ କରନ୍ତୁ",
    phoneHelp: "ସ୍ୱୟଂଚାଳିତ ଦାଖଲକୁ ରୋକିବା ପାଇଁ ପରବର୍ତ୍ତୀ ସ୍କ୍ରିନରେ ଛଅ ଅଙ୍କର କୋଡ୍ ଦେଖାଯିବ।",
    requestVerification: "ଯାଞ୍ଚ ପାଇଁ ଆଗକୁ ବଢ଼ନ୍ତୁ",
    otpTitle: "ଯାଞ୍ଚ ସମ୍ପୂର୍ଣ୍ଣ କରନ୍ତୁ",
    otpHelp: "ତଳେ ଦେଖାଯାଇଥିବା କୋଡ୍ ଦିଅନ୍ତୁ। ଏହା ସହି ପ୍ରକ୍ରିୟାକୁ ଯାଞ୍ଚ କରେ, ମୋବାଇଲ ନମ୍ବର ମାଲିକାନାକୁ ନୁହେଁ।",
    verifyCode: "ଯାଞ୍ଚ କରନ୍ତୁ",
    verificationProtected: "ଯାଞ୍ଚ-ସୁରକ୍ଷିତ ଅଂଶଗ୍ରହଣ",
    resendOtp: "ନୂଆ କୋଡ୍ ନିଅନ୍ତୁ",
    phoneVerified: "ଯାଞ୍ଚ ସମ୍ପୂର୍ଣ୍ଣ",
    verificationCompleteBody: "ସହି ଯାଞ୍ଚ ସମ୍ପୂର୍ଣ୍ଣ ହୋଇଛି। ମୋବାଇଲ ନମ୍ବର ଓ ଇମେଲ୍ ମାଲିକାନା ଯାଞ୍ଚ ହୋଇନାହିଁ।",
    profileTitle: "ଆପଣଙ୍କ ସହି ପ୍ରୋଫାଇଲ",
    profileHelp: "ଆବଶ୍ୟକ ସମର୍ଥକ ବିବରଣୀ ଦିଅନ୍ତୁ।",
    emailLabel: "ଇମେଲ",
    emailPlaceholder: "ଇମେଲ",
    authorityLabel: "ଆପଣଙ୍କ ଅପିଲ ପାଇଁ କର୍ତ୍ତୃପକ୍ଷ ବାଛନ୍ତୁ",
    addOptionalDetails: "ବୈକଳ୍ପିକ ବିବରଣୀ ଯୋଡନ୍ତୁ",
    detailsTitle: "ଆବଶ୍ୟକ ସ୍ଥାନ ଏବଂ ବୈକଳ୍ପିକ ବିବରଣୀ",
    detailsHelp: "ସ୍ଥାନ ଅଭିଯାନକୁ ସମର୍ଥନ କେଉଁଠାରୁ ଆସୁଛି ଦେଖାଇବାରେ ସାହାଯ୍ୟ କରେ।",
    locationLimitTitle: "ଏହି ଅଭିଯାନ ସୀମିତ",
    addressLabel: "ଠିକଣା",
    addressPlaceholder: "ଘର, ରାସ୍ତା, ସ୍ଥାନୀୟ ଅଞ୍ଚଳ",
    optionalDetails: "ଯୋଗାଯୋଗ ଏବଂ ରେଫରାଲ ବିକଳ୍ପ",
    whatsappLabel: "WhatsApp ନମ୍ବର",
    whatsappPlaceholder: "ଫୋନରୁ ଭିନ୍ନ ହେଲେ",
    telegramLabel: "Telegram ହ୍ୟାଣ୍ଡଲ କିମ୍ବା ନମ୍ବର",
    telegramPlaceholder: "@handle କିମ୍ବା ନମ୍ବର",
    referralLabel: "ରେଫର କରିଥିବା ଫୋନ, ନାମ, କିମ୍ବା କୋଡ୍",
    referralHelp: "କେହି ଆମନ୍ତ୍ରଣ କରିଥିଲେ ଫୋନ, ନାମ, କିମ୍ବା କୋଡ୍ ବ୍ୟବହାର କରନ୍ତୁ।",
    reviewTitle: "ସମୀକ୍ଷା କରନ୍ତୁ ଏବଂ ସହି କରନ୍ତୁ",
    reviewHelp: "ଆପଣଙ୍କ ସମର୍ଥନ ନିଶ୍ଚିତ କରି ସହି ଦାଖଲ କରନ୍ତୁ।",
    reviewAuthority: "କର୍ତ୍ତୃପକ୍ଷ",
    reviewReferral: "ରେଫରାଲ",
    notEntered: "ଦିଆଯାଇନାହିଁ",
    none: "କିଛି ନାହିଁ",
    trustLabel: "ଭରସା ଏବଂ ଗୋପନୀୟତା",
    privacyRespected: "ଗୋପନୀୟତାର ସମ୍ମାନ",
    storedSecurely: "ସଫଳ ଦାଖଲ ପରେ ହିଁ ସୁରକ୍ଷିତ ଭାବେ ସଂରକ୍ଷିତ ହେବ",
    routedAuthority: "ଚୟିତ କର୍ତ୍ତୃପକ୍ଷଙ୍କ ପାଇଁ ପ୍ରସ୍ତୁତ; ଏପର୍ଯ୍ୟନ୍ତ ପଠାଯାଇଥିବା ଦାବି ନୁହେଁ",
    supportCheckbox: "ମୁଁ ଉପରେ ଦେଖାଯାଇଥିବା ଅଭିଯାନ ଅପିଲ/କାରଣ ପଢିଛି ଏବଂ ସମର୍ଥନ କରୁଛି।",
    consentRequiredInline: "ସହି କରିବା ପୂର୍ବରୁ ଦୁଇଟି ସମ୍ମତି ନିଶ୍ଚିତକରଣ ଗ୍ରହଣ କରନ୍ତୁ।",
    doneBody: "ଆପଣଙ୍କ ଆବାଜ ରେକର୍ଡ ହୋଇଛି। ପରବର୍ତ୍ତୀ ସମର୍ଥକଙ୍କୁ ପହଞ୍ଚିବା ପାଇଁ ଅଭିଯାନ ସେୟାର କରନ୍ତୁ।",
    locationLabels: {
      country: "ଦେଶ",
      state: "ରାଜ୍ୟ / କେନ୍ଦ୍ରଶାସିତ ଅଞ୍ଚଳ",
      district: "ଜିଲ୍ଲା",
      block: "ବ୍ଲକ / ତହସିଲ / ତାଲୁକ",
      panchayat: "ଗ୍ରାମ ପଞ୍ଚାୟତ / ୱାର୍ଡ",
      postalCode: "PIN / ପୋଷ୍ଟାଲ କୋଡ୍"
    }
  }
};

interface PublicExperienceCopy {
  signNow: string;
  campaignAtGlance: string;
  locationTitle: string;
  locationHelp: string;
  submitWorking: string;
  otpSending: string;
  otpVerifying: string;
  optionalNext: string;
  helpOrganise: string;
  notNow: string;
  learnMore: string;
  becomeCoordinator: string;
  coordinatorLearn: string;
  coordinatorHandoff: string;
  coordinatorContact: string;
  coordinatorPending: string;
  nationwideReach: string;
  statesReached: string;
  districtsReached: string;
  paperSupporters: string;
  remainingToGoal: string;
  structuredLocationTitle: string;
  structuredLocationHelp: string;
  paperReminderTitle: string;
  paperReminderWithCount: string;
  paperReminderEmpty: string;
  photo: PublicSupporterPhotoCopy;
}

const publicExperienceCopyEn: PublicExperienceCopy = {
  signNow: "SIGN NOW",
  campaignAtGlance: "Campaign at a glance",
  locationTitle: "Location (Optional)",
  locationHelp: "Location is optional. Choose your administrative area using the fields below.",
  submitWorking: "Recording support...",
  otpSending: "Sending...",
  otpVerifying: "Verifying...",
  optionalNext: "Optional next steps",
  helpOrganise: "Would you like to help organise this campaign?",
  notNow: "Not Now",
  learnMore: "Learn More",
  becomeCoordinator: "Become Coordinator",
  coordinatorLearn: "Coordinators help organise verified local activity through the existing campaign hierarchy.",
  coordinatorHandoff: "For security, a campaign manager must create the invited coordinator inside Coordinator Network.",
  coordinatorContact: "Request an invitation",
  coordinatorPending: "Invitation requested",
  nationwideReach: "Nationwide campaign reach",
  statesReached: "States / UTs reached",
  districtsReached: "Districts reached",
  paperSupporters: "Paper signatures",
  remainingToGoal: "Verified support needed",
  structuredLocationTitle: "Confirmed administrative path",
  structuredLocationHelp: "Matched against the India geography hierarchy. Review every field before signing.",
  paperReminderTitle: "Already signed on paper?",
  paperReminderWithCount: "{count} paper signatures are already included. Use the same mobile number so duplicates can be identified safely.",
  paperReminderEmpty: "Use the same mobile number if you signed a paper sheet. Paper entries may require review before appearing in totals.",
  photo: {
    title: "Optional private photo",
    help: "Add a profile photo after signing",
    selfie: "Take Selfie",
    rearCamera: "Rear Camera",
    choosePhoto: "Upload",
    skip: "Skip",
    retake: "Retake",
    rotate: "Rotate",
    crop: "Crop / zoom",
    lighting: "Use even lighting and keep your face inside the preview. The photo stays private.",
    upload: "Upload privately",
    uploading: "Uploading...",
    uploaded: "Private photo uploaded.",
    invalidImage: "Choose a JPEG, PNG, or WebP image up to 5 MB.",
    uploadFailed: "Private photo upload failed."
  }
};

const publicExperienceCopy: Record<Language, PublicExperienceCopy> = {
  en: publicExperienceCopyEn,
  hi: {
    signNow: "अभी हस्ताक्षर करें",
    campaignAtGlance: "अभियान एक नज़र में",
  locationTitle: "स्थान (वैकल्पिक)",
    locationHelp: "स्थान वैकल्पिक है। नीचे दिए गए फ़ील्ड से अपना प्रशासनिक स्थान चुनें।",
    submitWorking: "समर्थन दर्ज हो रहा है...",
    otpSending: "भेजा जा रहा है...",
    otpVerifying: "सत्यापित हो रहा है...",
    optionalNext: "वैकल्पिक अगले कदम",
    helpOrganise: "क्या आप इस अभियान को व्यवस्थित करने में मदद करना चाहेंगे?",
    notNow: "अभी नहीं",
    learnMore: "और जानें",
    becomeCoordinator: "समन्वयक बनें",
    coordinatorLearn: "समन्वयक मौजूदा अभियान पदानुक्रम के माध्यम से सत्यापित स्थानीय गतिविधि व्यवस्थित करते हैं।",
    coordinatorHandoff: "सुरक्षा के लिए अभियान प्रबंधक को समन्वयक नेटवर्क में आमंत्रित समन्वयक बनाना होगा।",
    coordinatorContact: "आमंत्रण का अनुरोध करें",
    coordinatorPending: "आमंत्रण का अनुरोध भेजा गया",
    nationwideReach: "राष्ट्रव्यापी अभियान पहुँच",
    statesReached: "राज्य / केंद्र शासित प्रदेश",
    districtsReached: "जिले",
    paperSupporters: "कागज़ी हस्ताक्षर",
    remainingToGoal: "लक्ष्य के लिए सत्यापित समर्थन",
    structuredLocationTitle: "पुष्ट प्रशासनिक मार्ग",
    structuredLocationHelp: "भारत के भूगोल पदानुक्रम से मिलान किया गया। हस्ताक्षर से पहले हर फ़ील्ड की समीक्षा करें।",
    paperReminderTitle: "क्या आपने पहले कागज़ पर हस्ताक्षर किए हैं?",
    paperReminderWithCount: "{count} कागज़ी हस्ताक्षर पहले से शामिल हैं। डुप्लिकेट सुरक्षित रूप से पहचानने के लिए वही मोबाइल नंबर उपयोग करें।",
    paperReminderEmpty: "यदि आपने कागज़ी शीट पर हस्ताक्षर किए हैं तो वही मोबाइल नंबर उपयोग करें। कुल में आने से पहले कागज़ी प्रविष्टियों की समीक्षा हो सकती है।",
    photo: {
      title: "वैकल्पिक निजी फ़ोटो",
      help: "हस्ताक्षर के बाद प्रोफ़ाइल फ़ोटो जोड़ें",
      selfie: "सेल्फ़ी लें",
      rearCamera: "पिछला कैमरा",
      choosePhoto: "अपलोड",
      skip: "छोड़ें",
      retake: "फिर लें",
      rotate: "घुमाएँ",
      crop: "क्रॉप / ज़ूम",
      lighting: "समान रोशनी रखें और चेहरा प्रीव्यू के अंदर रखें। फ़ोटो निजी रहेगी।",
      upload: "निजी रूप से अपलोड करें",
      uploading: "अपलोड हो रहा है...",
      uploaded: "निजी फ़ोटो अपलोड हुई।",
      invalidImage: "5 MB तक JPEG, PNG या WebP छवि चुनें।",
      uploadFailed: "निजी फ़ोटो अपलोड विफल हुई।"
    }
  },
  or: {
    signNow: "ଏବେ ସହି କରନ୍ତୁ",
    campaignAtGlance: "ଅଭିଯାନ ଏକ ନଜରରେ",
  locationTitle: "ସ୍ଥାନ (ବୈକଳ୍ପିକ)",
    locationHelp: "ସ୍ଥାନ ବୈକଳ୍ପିକ। ତଳେ ଥିବା କ୍ଷେତ୍ରଗୁଡ଼ିକରୁ ପ୍ରଶାସନିକ ସ୍ଥାନ ବାଛନ୍ତୁ।",
    submitWorking: "ସମର୍ଥନ ରେକର୍ଡ ହେଉଛି...",
    otpSending: "ପଠାଯାଉଛି...",
    otpVerifying: "ଯାଞ୍ଚ ହେଉଛି...",
    optionalNext: "ବୈକଳ୍ପିକ ପରବର୍ତ୍ତୀ ପଦକ୍ଷେପ",
    helpOrganise: "ଆପଣ ଏହି ଅଭିଯାନ ସଂଗଠିତ କରିବାରେ ସାହାଯ୍ୟ କରିବେ କି?",
    notNow: "ଏବେ ନୁହେଁ",
    learnMore: "ଅଧିକ ଜାଣନ୍ତୁ",
    becomeCoordinator: "ସମନ୍ୱୟକାରୀ ହୁଅନ୍ତୁ",
    coordinatorLearn: "ସମନ୍ୱୟକାରୀମାନେ ବର୍ତ୍ତମାନର ଅଭିଯାନ ପଦାନୁକ୍ରମ ମାଧ୍ୟମରେ ସତ୍ୟାପିତ ସ୍ଥାନୀୟ କାର୍ଯ୍ୟକଳାପ ସଂଗଠିତ କରନ୍ତି।",
    coordinatorHandoff: "ସୁରକ୍ଷା ପାଇଁ ଅଭିଯାନ ପରିଚାଳକଙ୍କୁ ସମନ୍ୱୟକାରୀ ନେଟୱର୍କରେ ଆମନ୍ତ୍ରିତ ସମନ୍ୱୟକାରୀ ସୃଷ୍ଟି କରିବାକୁ ପଡ଼ିବ।",
    coordinatorContact: "ଆମନ୍ତ୍ରଣ ଅନୁରୋଧ କରନ୍ତୁ",
    coordinatorPending: "ଆମନ୍ତ୍ରଣ ଅନୁରୋଧ ପଠାଯାଇଛି",
    nationwideReach: "ଦେଶବ୍ୟାପୀ ଅଭିଯାନ ପହଞ୍ଚ",
    statesReached: "ରାଜ୍ୟ / କେନ୍ଦ୍ରଶାସିତ ଅଞ୍ଚଳ",
    districtsReached: "ଜିଲ୍ଲା",
    paperSupporters: "କାଗଜ ସହି",
    remainingToGoal: "ଲକ୍ଷ୍ୟ ପାଇଁ ସତ୍ୟାପିତ ସମର୍ଥନ",
    structuredLocationTitle: "ନିଶ୍ଚିତ ପ୍ରଶାସନିକ ପଥ",
    structuredLocationHelp: "ଭାରତର ଭୂଗୋଳ ପଦାନୁକ୍ରମ ସହିତ ମେଳ ହୋଇଛି। ସହି ପୂର୍ବରୁ ପ୍ରତ୍ୟେକ କ୍ଷେତ୍ର ସମୀକ୍ଷା କରନ୍ତୁ।",
    paperReminderTitle: "ଆପଣ ପୂର୍ବରୁ କାଗଜରେ ସହି କରିଛନ୍ତି କି?",
    paperReminderWithCount: "{count} କାଗଜ ସହି ପୂର୍ବରୁ ଅନ୍ତର୍ଭୁକ୍ତ। ନକଲ ସୁରକ୍ଷିତ ଭାବେ ଚିହ୍ନଟ ପାଇଁ ସେହି ମୋବାଇଲ୍ ନମ୍ବର ବ୍ୟବହାର କରନ୍ତୁ।",
    paperReminderEmpty: "କାଗଜ ସିଟ୍‌ରେ ସହି କରିଥିଲେ ସେହି ମୋବାଇଲ୍ ନମ୍ବର ବ୍ୟବହାର କରନ୍ତୁ। ମୋଟରେ ଆସିବା ପୂର୍ବରୁ କାଗଜ ଏଣ୍ଟ୍ରି ସମୀକ୍ଷା ହୋଇପାରେ।",
    photo: {
      title: "ବୈକଳ୍ପିକ ଘରୋଇ ଫଟୋ",
      help: "ସହି ପରେ ପ୍ରୋଫାଇଲ୍ ଫଟୋ ଯୋଡ଼ନ୍ତୁ",
      selfie: "ସେଲ୍ଫି ନିଅନ୍ତୁ",
      rearCamera: "ପଛ କ୍ୟାମେରା",
      choosePhoto: "ଅପଲୋଡ୍",
      skip: "ଛାଡ଼ନ୍ତୁ",
      retake: "ପୁଣି ନିଅନ୍ତୁ",
      rotate: "ଘୁରାନ୍ତୁ",
      crop: "କ୍ରପ୍ / ଜୁମ୍",
      lighting: "ସମାନ ଆଲୋକ ରଖନ୍ତୁ ଏବଂ ମୁହଁକୁ ପ୍ରିଭ୍ୟୁ ଭିତରେ ରଖନ୍ତୁ। ଫଟୋ ଘରୋଇ ରହିବ।",
      upload: "ଘରୋଇ ଭାବେ ଅପଲୋଡ୍ କରନ୍ତୁ",
      uploading: "ଅପଲୋଡ୍ ହେଉଛି...",
      uploaded: "ଘରୋଇ ଫଟୋ ଅପଲୋଡ୍ ହେଲା।",
      invalidImage: "5 MB ପର୍ଯ୍ୟନ୍ତ JPEG, PNG କିମ୍ବା WebP ଛବି ବାଛନ୍ତୁ।",
      uploadFailed: "ଘରୋଇ ଫଟୋ ଅପଲୋଡ୍ ବିଫଳ।"
    }
  }
};

function isContinuingSamePublicPhoneIdentity(previousPhone: string, nextPhone: string): boolean {
  if (!previousPhone || !nextPhone) return false;
  return previousPhone.startsWith(nextPhone) || nextPhone.startsWith(previousPhone);
}

function shouldStartNewJourneyForPhoneInput(
  previousPhone: string,
  nextPhone: string,
  form: Pick<typeof blankSigner, "otpVerified" | "otpChallengeId" | "otpVerificationToken">
): boolean {
  if (previousPhone === nextPhone) return false;
  if (form.otpVerified || form.otpChallengeId || form.otpVerificationToken) return true;
  return !isContinuingSamePublicPhoneIdentity(previousPhone, nextPhone);
}

export function PublicCampaignPage({
  campaign,
  organization,
  metrics,
  authority,
  authorities,
  campaignSigners,
  publicForm,
  setPublicForm,
  publicMessage,
  lastSignedSigner,
  supporterAccountClaimGrant = null,
  linkedSupporterAccount = null,
  onSupporterAccountLinked,
  otpInput,
  setOtpInput,
  otpMessage,
  onSendOtp,
  onVerifyOtp,
  onRetryVerifiedSupporterLookup = onVerifyOtp,
  locationOverrides,
  locationDeletions,
  customLocations = [],
  onGrowthShare,
  onUploadSupporterPhoto,
  onSaveDraft,
  onCommunicationConsentChange,
  onSubmitMovementRequest,
  movementRequests,
  movementRequestsLoading = false,
  movementRequestsError = "",
  onRefreshMovementRequests,
  onSubmitCoordinatorApplication,
  onStartNewJourney,
  onSubmit
}: PublicCampaignPageProps) {
  const { language, t } = useTranslation();
  const premiumPresentation = getPublicCampaignPresentation(campaign.slug);
  const presentationCopy = premiumPresentation
    ? getPublicCampaignPresentationCopy(premiumPresentation, language)
    : null;
  const isGoudhanExperience =
    Boolean(premiumPresentation) &&
    isGoudhanProductionCampaign(campaign, organization);
  const isGaumataHost =
    typeof window !== "undefined" &&
    isGaumataPublicHostname(window.location.hostname);
  const isGaumataCampaignExperience = isGoudhanExperience && isGaumataHost;
  const campaignHeroImage = sanitizePublicCampaignMediaUrl(campaign.heroImage);
  const campaignSupportingArtwork =
    premiumPresentation &&
    campaignHeroImage === premiumPresentation.placeholderHeroAsset
      ? ""
      : campaignHeroImage;
  const campaignHeroArtwork = sanitizePublicCampaignMediaUrl(
    premiumPresentation?.heroAsset.trim() || campaignSupportingArtwork
  );
  const displayCampaign: Campaign = isGoudhanExperience
    ? {
        ...campaign,
        title: t("goudhanCampaign.title"),
        description: t("goudhanCampaign.summary"),
        appealContent: t("goudhanCampaign.appeal"),
        socialShareText: t("goudhanCampaign.share"),
        thankYouMessage: t("goudhanCampaign.thankYou"),
        qrLabel: t("goudhanCampaign.qrLabel"),
        consentText: t("goudhanCampaign.consent"),
        heroImage: campaignHeroImage
      }
    : { ...campaign, heroImage: campaignHeroImage };
  const campaignAccountAccessPath = getCampaignLoginPath({
    campaignId: campaign.id,
    campaignSlug: campaign.slug
  });
  const publicOrganizationLabel = organization?.name?.trim() ?? "";
  const configuredAuthorityOptions = getAuthorityOptionsForCampaign(campaign, authorities);
  const publicAuthorityOptions = isGaumataCampaignExperience
    ? configuredAuthorityOptions
    : getPublicAuthorityOptions(campaign, authorities);
  const campaignConfiguredAuthority =
    getConfiguredAppealAuthority(campaign, authorities);
  const configuredAuthority = authority ?? campaignConfiguredAuthority;
  const hasConfiguredAuthority = Boolean(configuredAuthority);
  const showNeutralAuthority =
    isGaumataCampaignExperience && !hasConfiguredAuthority;
  const resolvedAuthority = configuredAuthority ?? getAppealAuthority(campaign);
  const isGlobalMode = getCampaignGeographyMode(campaign) === "global";
  const locationLabels = getCampaignLocationLabels(campaign);
  const signerRestrictionLevel = getEffectiveSignerLocationRestrictionLevel(campaign, organization);
  const restrictedPublicForm = applySignerLocationRestriction(campaign, publicForm, organization);
  const publicLocationForm =
    isGlobalMode && getCampaignScope(campaign) !== "global" && campaign.country && !restrictedPublicForm.country
      ? { ...restrictedPublicForm, country: campaign.country }
      : restrictedPublicForm;
  const restrictionMessage = getLocationRestrictionMessage(campaign, organization);
  const lockedLocation = {
    ...(isGlobalMode && getCampaignScope(campaign) !== "global" && campaign.country
      ? { country: campaign.country }
      : {}),
    ...getLockedLocationValues(campaign, signerRestrictionLevel)
  };
  const lockedLocationParts = formatLocationForCampaign(campaign, lockedLocation).split(", ").filter(Boolean);
  const publicIndiaAllowedLocation = lockedLocation.state?.trim() ? lockedLocation : undefined;
  const campaignCustomLocations = (campaign as Campaign & { customLocations?: unknown }).customLocations;
  const publicCampaignLocationCatalog = usePublicCampaignLocationCatalog(campaign.slug, publicLocationForm);
  const signerLocationCatalog = useMemo(
    () => resolveIndiaLocationCatalog(
      [...customLocations, ...publicCampaignLocationCatalog.locations],
      campaignCustomLocations
    ),
    [campaignCustomLocations, customLocations, publicCampaignLocationCatalog.locations]
  );
  const requiredFields = campaign.requiredFields ?? [];
  const copy = publicSigningCopy[language];
  const experienceCopy = publicExperienceCopy[language];
  const addressLabel = copy.addressLabel;
  const addressPlaceholder = copy.addressPlaceholder;
  const locationSectionTitle = isGoudhanExperience
    ? t("goudhanCampaign.locationTitle")
    : experienceCopy.locationTitle;
  const locationSectionHelp = isGoudhanExperience
    ? t("goudhanCampaign.locationHelp")
    : experienceCopy.locationHelp;
  const displayPublicMessage =
    publicMessage === "consent_required"
      ? t("public.consentRequiredInline")
      : publicMessage === "existing_supporter_duplicate"
        ? t("public.existingSupporterDuplicate")
        : publicMessage;
  const publicMessageIsError =
    publicMessage === "consent_required" ||
    publicMessage === "existing_supporter_duplicate" ||
    isPublicFailureMessage(displayPublicMessage);
  const safeOtpMessage = getSafeOtpDisplayMessage(otpMessage, {
    hostname: typeof window === "undefined" ? "" : window.location.hostname,
    isDevelopment: import.meta.env.DEV,
    explicitTestDisplayEnabled: import.meta.env.VITE_VOICEUP_SHOW_OTP === "true",
    neutralMessage: copy.otpHelp
  });
  const otpMessageIsError =
    safeOtpMessage.trim() !== copy.otpHelp.trim() && isPublicFailureMessage(safeOtpMessage);
  const signerFieldLabel = (label: string, field: SignerRequiredField) =>
    requiredFields.includes(field) ? `${label} *` : label;
  const prefersReducedMotion = useMemo(() => {
    if (typeof window === "undefined") return false;
    return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }, []);
  const [audioEnabled, setAudioEnabled] = useState(false);
  const mantraAudioRef = useRef<HTMLAudioElement | null>(null);
  const [monkpujaVideoIndex, setMonkpujaVideoIndex] = useState(0);
  const monkpujaVideoSources = ["/assets/gemini_generated_video_4.mp4"] as const;
  const [panchagavyaVideoIndex, setPanchagavyaVideoIndex] = useState(0);
  const panchagavyaVideoSources = ["/assets/panchagabyavideo.mp4", "/assets/dhanlaxmi.mp4"] as const;

  useEffect(() => {
    const audio = mantraAudioRef.current;
    if (!audio) return;

    audio.src = "/assets/sri-surabhyai-namah.mp3";
    audio.load();
    audio.volume = 0.25;
    audio.loop = true;
    audio.muted = false;

    void audio.play().then(() => {
      setAudioEnabled(true);
    }).catch(() => {
      setAudioEnabled(false);
    });
  }, []);

  const handleMantraToggle = async () => {
    const audio = mantraAudioRef.current;
    if (!audio) return;
    if (audioEnabled) {
      audio.pause();
      audio.muted = false;
      setAudioEnabled(false);
      return;
    }
    try {
      audio.volume = 0.25;
      audio.loop = true;
      audio.muted = false;
      await audio.play();
      setAudioEnabled(true);
    } catch (error) {
      console.warn("Unable to play mantra audio on demand:", error);
      audio.pause();
      setAudioEnabled(false);
    }
  };
  const publicUrl = getCampaignPublicUrl(organization, campaign);
  const incomingReferralCode = useMemo(() => {
    if (typeof window === "undefined") return "";
    return normalizeReferralCode(new URLSearchParams(window.location.search).get("ref") ?? "");
  }, [campaign.id]);
  const incomingReferrer = findReferrer(campaignSigners, campaign.id, incomingReferralCode);
  const typedReferral = publicForm.referredByPhoneOrCode?.trim() ?? "";
  const typedReferrer = typedReferral ? findReferrer(campaignSigners, campaign.id, typedReferral) : undefined;
  const isSelfReferral = Boolean(typedReferrer && typedReferrer.phone.replace(/\D/g, "") === publicForm.phone.replace(/\D/g, ""));
  const personalReferralCode =
    lastSignedSigner?.campaignId === campaign.id ? getPersistedSupporterReferralCode(lastSignedSigner) : "";
  const personalReferralUrl = personalReferralCode
    ? getCampaignReferralUrl(organization, campaign, personalReferralCode)
    : publicUrl;
  const configuredShareMessages = getConfiguredGrowthShareMessages({
    campaign: displayCampaign,
    organization,
    signer: lastSignedSigner,
    referralLink: personalReferralUrl,
    campaignProgress: metrics.progress,
    supporterCount: metrics.total,
    verifiedSupporters: metrics.verified
  });
  const shareMessages = isGoudhanExperience
    ? {
        ...configuredShareMessages,
        whatsapp: `${displayCampaign.socialShareText}\n${personalReferralUrl}`,
        emailSubject: displayCampaign.title,
        emailBody: `${displayCampaign.socialShareText}\n${personalReferralUrl}`,
        social: displayCampaign.socialShareText,
        instagramCaption: displayCampaign.socialShareText
      }
    : configuredShareMessages;
  const [copiedReferral, setCopiedReferral] = useState("");
  const [wizardStep, setWizardStep] = useState<SigningStepId>(
    publicForm.otpVerified ||
    (publicForm.verificationMethod === "screen_otp" && Boolean(publicForm.otpVerificationToken))
      ? "profile"
      : "phone"
  );
  const [participationMode, setParticipationMode] = useState<"support" | "sign_in">(() =>
    typeof window !== "undefined" && window.location.hash === "#campaign-sign-in"
      ? "sign_in"
      : "support"
  );
  const [supporterRoutingPrecheck, setSupporterRoutingPrecheck] =
    useState<PublicSupporterRoutingPrecheck | null>(() => readSupporterRoutingPrecheck(campaign.id));
  const [supporterRoutingChecking, setSupporterRoutingChecking] = useState(false);
  const [supporterRoutingError, setSupporterRoutingError] = useState(false);
  const [supporterRoutingAttempt, setSupporterRoutingAttempt] = useState(0);
  const [verificationOutcome, setVerificationOutcome] =
    useState<PublicSigningVerificationOutcome | null>(null);
  // A server-confirmed duplicate is a returning-supporter journey, not a
  // reason to repeat the six-step signing form. Authentication remains required.
  useEffect(() => {
    if (publicMessage !== "existing_supporter_duplicate") return;
    setVerificationOutcome("secure_access_required");
    setParticipationMode("sign_in");
  }, [publicMessage]);
  const [returningSupporterDetected, setReturningSupporterDetected] = useState(false);
  const [retryingSupporterLookup, setRetryingSupporterLookup] = useState(false);
  const [restoredDraftStorageKey, setRestoredDraftStorageKey] = useState("");
  const [sendingOtp, setSendingOtp] = useState(false);
  const [verifyingOtp, setVerifyingOtp] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [postSignPanel, setPostSignPanel] = useState<InvolvementPanel>("none");
  const [coordinatorLearnMore, setCoordinatorLearnMore] = useState(false);
  const [communicationConsent, setCommunicationConsent] = useState(false);
  const [appealConsent, setAppealConsent] = useState(false);
  const [campaignConsent, setCampaignConsent] = useState(false);
  const [photoPanelDismissed, setPhotoPanelDismissed] = useState(false);
  const [volunteerSkills, setVolunteerSkills] = useState("");
  const [volunteerInterests, setVolunteerInterests] = useState("");
  const [volunteerAvailability, setVolunteerAvailability] = useState("");
  const [volunteerWorkingArea, setVolunteerWorkingArea] = useState("");
  const [volunteerConsent, setVolunteerConsent] = useState(false);
  const [coordinatorLevel, setCoordinatorLevel] =
    useState<ParticipationRequestLevel>("ward");
  const [coordinatorMinimumLevel, setCoordinatorMinimumLevel] =
    useState<ParticipationRequestLevel | "">("");
  const [coordinatorLocation, setCoordinatorLocation] = useState<LocationWithPin>({
    country: "India",
    state: "",
    district: "",
    block: "",
    panchayat: "",
    postalCode: ""
  });
  const [coordinatorLocationReference, setCoordinatorLocationReference] =
    useState<PersistedLocationReference | null>(null);
  const [coordinatorWard, setCoordinatorWard] = useState("");
  const [coordinatorExperience, setCoordinatorExperience] = useState("");
  const [coordinatorMotivation, setCoordinatorMotivation] = useState("");
  const [coordinatorAvailability, setCoordinatorAvailability] = useState("");
  const [coordinatorConsent, setCoordinatorConsent] = useState(false);
  const [submittingMovementRequest, setSubmittingMovementRequest] = useState(false);
  const [savedMovementRequests, setSavedMovementRequests] =
    useState<PublicParticipationRequest[]>([]);
  const [showMovementDashboard, setShowMovementDashboard] = useState(false);
  const [movementRequestError, setMovementRequestError] = useState("");
  const movementRequestAttemptRef = useRef<{
    fingerprint: string;
    idempotencyKey: string;
  } | null>(null);
  const stepHeadingRef = useRef<HTMLHeadingElement>(null);
  const publicMessageRef = useRef<HTMLParagraphElement>(null);
  const movementRequestResultRef = useRef<HTMLHeadingElement>(null);
  const previousWizardStepRef = useRef<SigningStepId>(wizardStep);
  const hasSignedCampaign = lastSignedSigner?.campaignId === campaign.id;
  const publicVerificationComplete = Boolean(
    publicForm.otpVerificationToken &&
    (publicForm.otpVerified || publicForm.verificationMethod === "screen_otp")
  );
  const campaignGoal = getCampaignGoalValue(campaign);
  const configuredCampaignGoal =
    Number.isFinite(campaign.goal) && campaign.goal > 0 ? campaign.goal : null;
  const signingCampaignScope = useMemo(
    () => ({ campaignId: campaign.id, slug: campaign.slug }),
    [campaign.id, campaign.slug]
  );
  const draftStorageKey = getPublicSigningJourneyStorageKey(signingCampaignScope);
  const isRequired = (field: SignerRequiredField) => requiredFields.includes(field);
  const emailRequired = isRequired("email") || isGoudhanExperience;
  const locationRequired = requiredFields.some((field) =>
    ["country", "state", "district", "block", "panchayat", "postalCode"].includes(field)
  );
  const detailsRequired = Boolean(restrictionMessage || locationRequired || isRequired("address"));
  const hasOptionalDetails = Boolean(
    publicForm.country ||
      publicForm.state ||
      publicForm.district ||
      publicForm.block ||
      publicForm.panchayat ||
      publicForm.postalCode ||
      publicForm.address ||
      publicForm.whatsappNumber ||
      publicForm.telegramHandle ||
      publicForm.referredByPhoneOrCode
  );
  const activeSigningSteps = signingSteps.filter(
    (step) => step.id !== "address" || detailsRequired || hasOptionalDetails || wizardStep === "address"
  );
  const activeStepIndex = Math.max(0, activeSigningSteps.findIndex((step) => step.id === wizardStep));
  const indianMobile = normalizeIndianMobileInput(publicForm.phone);
  const phoneDigits = publicForm.phone.replace(/\D/g, "");
  const phoneNumberReady =
    premiumPresentation
      ? indianMobile.valid
      : /^[0-9+()\s-]+$/.test(publicForm.phone.trim()) &&
        phoneDigits.length >= 8 &&
        phoneDigits.length <= 15;
  const phoneReady = phoneNumberReady;
  const showPhoneError = premiumPresentation
    ? indianMobile.complete && !indianMobile.valid
    : Boolean(publicForm.phone.trim()) && !phoneNumberReady;
  const otpReady = /^\d{6}$/.test(otpInput.trim());
  const emailReady = publicForm.email.trim()
    ? isValidPublicSignerEmail(publicForm.email)
    : !emailRequired;
  const profileReady =
    (!isRequired("name") || Boolean(publicForm.name.trim())) && emailReady;
  const detailsReady = requiredFields
    .filter((field) =>
      ["country", "state", "district", "block", "panchayat", "postalCode", "address"].includes(field)
    )
    .every((field) => Boolean(restrictedPublicForm[field]?.trim()));
  const requiredConsentsAccepted = appealConsent && campaignConsent;

  useEffect(() => {
    if (wizardStep !== "phone") {
      setSupporterRoutingChecking(false);
      setSupporterRoutingError(false);
      return;
    }
    if (!phoneReady) {
      clearSupporterRoutingPrecheck(campaign.id);
      setSupporterRoutingPrecheck(null);
      setSupporterRoutingChecking(false);
      setSupporterRoutingError(false);
      return;
    }
    clearSupporterRoutingPrecheck(campaign.id);
    setSupporterRoutingPrecheck(null);
    setSupporterRoutingChecking(true);
    setSupporterRoutingError(false);
    let active = true;
    const timer = window.setTimeout(() => {
      void precheckPublicSupporterRouting(campaign.slug, publicForm.phone)
        .then((precheck) => {
          if (!active) return;
          writeSupporterRoutingPrecheck(campaign.id, precheck);
          setSupporterRoutingPrecheck(precheck);
        })
        .catch(() => {
          if (!active) return;
          // Preserve the entered number and require an explicit retry instead
          // of bypassing the server-side routing check.
          clearSupporterRoutingPrecheck(campaign.id);
          setSupporterRoutingPrecheck(null);
          setSupporterRoutingError(true);
        })
        .finally(() => {
          if (active) setSupporterRoutingChecking(false);
        });
    }, 450);
    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [campaign.id, campaign.slug, phoneReady, publicForm.phone, supporterRoutingAttempt, wizardStep]);
  const currentStepLabel =
    wizardStep === "review" ? t("public.review") : copy.steps[wizardStep];
  const stepProgressLabel = t("public.stepProgress")
    .replace("{current}", String(activeStepIndex + 1))
    .replace("{total}", String(activeSigningSteps.length))
    .replace("{step}", currentStepLabel);
  const heroSummary =
    displayCampaign.description.trim() ||
    t("public.defaultCampaignSummary").replace("{campaign}", displayCampaign.title);
  const signedAtValues = campaignSigners
    .map((signer) => signer.signedAt?.trim())
    .filter((value): value is string => Boolean(value))
    .sort();
  const latestSignatureAt = signedAtValues.length > 0 ? signedAtValues[signedAtValues.length - 1] : undefined;
  const localizedGoudhanUpdate = renderCampaignMessage(t("goudhanCampaign.latestUpdate"),
    { ...displayCampaign, shareUrl: publicUrl },
    metrics
  );
  const campaignUpdates = campaign.participantUpdateMessage.trim()
    ? [
        isGoudhanExperience
          ? localizedGoudhanUpdate
          : renderCampaignMessage(
              campaign.participantUpdateMessage,
              { ...displayCampaign, shareUrl: publicUrl },
              metrics
            )
      ]
    : [];
  const youtubeEmbedUrl = getYouTubeEmbedUrl(campaign.campaignVideoUrl);
  const configuredCampaignMedia = Boolean(displayCampaign.heroImage || campaign.campaignVideoUrl.trim());
  const hasCampaignMedia = premiumPresentation
    ? Boolean(campaignSupportingArtwork || campaign.campaignVideoUrl.trim())
    : configuredCampaignMedia;
  const premiumVisibleMetrics = premiumPresentation && presentationCopy
    ? getVisiblePublicMetrics([
        { key: "online", label: presentationCopy.statOnline, value: metrics.online },
        { key: "verified", label: presentationCopy.statVerified, value: metrics.verified },
        {
          key: "paper",
          label: presentationCopy.statHardcopy,
          value: metrics.scanned
        },
        {
          key: "goal",
          label: t("campaignAdmin.fields.targetSignatures"),
          value: configuredCampaignGoal
        },
        {
          key: "total",
          label: presentationCopy.statTotal,
          value: metrics.total
        }
      ])
    : [];
  const authorityCards = (
    showNeutralAuthority
      ? []
      : campaign.authoritySelectionMode === "public_choice" && publicAuthorityOptions.length > 0
        ? publicAuthorityOptions
        : [resolvedAuthority]
  ).slice(0, 3);
  const storyCards = [
    {
      icon: <HeartHandshake size={20} />,
      title: t("public.story.publicAsk"),
      body: displayCampaign.appealContent || displayCampaign.description
    },
    ...(showNeutralAuthority
      ? []
      : [{
          icon: <Landmark size={20} />,
          title: t("public.story.recipient"),
          body: formatAuthorityDisplay(resolvedAuthority)
        }]),
    {
      icon: <CalendarDays size={20} />,
      title: t("public.story.window"),
      body: [campaign.startDate, campaign.endDate].filter(Boolean).join(` ${t("public.to")} `)
    }
  ].filter((item) => item.body.trim());
  const movementMatterCards = (
    presentationCopy
      ? [
          {
            icon: <HeartHandshake size={20} />,
            title: presentationCopy.pillars[0],
            body: displayCampaign.description
          },
          {
            icon: <ShieldCheck size={20} />,
            title: presentationCopy.pillars[1],
            body: displayCampaign.appealContent
          },
          {
            icon: <Users size={20} />,
            title: presentationCopy.pillars[2],
            body: displayCampaign.socialShareText || displayCampaign.appealContent
          }
        ]
      : [
          {
            icon: <ClipboardList size={20} />,
            title: t("public.movement.problem"),
            body: displayCampaign.description
          },
          {
            icon: <HeartHandshake size={20} />,
            title: t("public.movement.whyItMatters"),
            body: displayCampaign.appealContent
          },
          {
            icon: <Landmark size={20} />,
            title: t("public.movement.desiredChange"),
            body: displayCampaign.appealContent
          },
          {
            icon: <Users size={20} />,
            title: t("public.movement.supporterHelp"),
            body: displayCampaign.socialShareText || displayCampaign.appealContent
          }
        ]
  ).filter((item) => item.body.trim());
  const movementTrustItems = [
    campaign.status === "Published"
      ? {
          icon: <CheckCircle2 size={20} />,
          label: t("public.movement.campaignStatus"),
          value: t("campaignAdmin.status.published"),
          href: undefined
        }
      : null,
    organization?.name.trim()
      ? {
          icon: <Users size={20} />,
          label: t("public.movement.organiser"),
          value: organization.name.trim(),
          href: undefined
        }
      : null,
    campaignConfiguredAuthority
      ? {
          icon: <Landmark size={20} />,
          label: t("public.movement.receivingAuthority"),
          value: formatAuthorityDisplay(campaignConfiguredAuthority),
          href: undefined
        }
      : null,
    displayCampaign.consentText.trim()
      ? {
          icon: <ShieldCheck size={20} />,
          label: t("public.movement.transparency"),
          value: displayCampaign.consentText.trim(),
          href: undefined
        }
      : null,
    campaign.adminEmail.trim()
      ? {
          icon: <Mail size={20} />,
          label: t("public.movement.campaignContact"),
          value: campaign.adminEmail.trim(),
          href: `mailto:${campaign.adminEmail.trim()}`
        }
      : null
  ].filter((item): item is NonNullable<typeof item> => Boolean(item));
  const movementFaqItems = [
    {
      question: t("public.movement.faqWhyJoin"),
      answer: displayCampaign.description
    },
    {
      question: t("public.movement.faqInformation"),
      answer: displayCampaign.consentText
    },
    {
      question: t("public.movement.faqVolunteer"),
      answer: t("public.movement.faqVolunteerAnswer")
    },
    {
      question: t("public.movement.faqSubmission"),
      answer: campaignConfiguredAuthority
        ? t("public.movement.faqSubmissionConfigured").replace(
            "{authority}",
            formatAuthorityDisplay(campaignConfiguredAuthority)
          )
        : t("public.movement.faqSubmissionPending")
    },
    ...(organization?.name.trim()
      ? [{
          question: t("public.movement.faqOrganising"),
          answer: t("public.movement.faqOrganisingAnswer").replace(
            "{organiser}",
            organization.name.trim()
          )
        }]
      : [])
  ].filter((item) => item.answer.trim());
  const minimumCoordinatorLevels = getMinimumParticipationLevels(coordinatorLevel);
  const coordinatorRequiredFields: SignerRequiredField[] =
    coordinatorLevel === "national"
      ? []
      : coordinatorLevel === "state"
        ? ["state"]
        : coordinatorLevel === "district"
          ? ["state", "district"]
          : coordinatorLevel === "block"
            ? ["state", "district", "block"]
            : ["state", "district", "block", "panchayat"];
  const coordinatorLocationReady =
    coordinatorRequiredFields.every((field) =>
      Boolean(coordinatorLocation[field as keyof LocationWithPin]?.trim())
    )
    && (coordinatorLevel !== "ward" || Boolean(coordinatorWard.trim()));
  const requestConsentVersion = createConsentVersion(displayCampaign.consentText);
  const savedMovementRequest = savedMovementRequests[0] ?? null;
  const requestDateLocale =
    language === "hi" ? "hi-IN" : language === "or" ? "or-IN" : "en-IN";
  const shareText = `${shareMessages.social}\n${personalReferralUrl}`;
  const whatsappText = shareMessages.whatsapp.includes(personalReferralUrl)
    ? shareMessages.whatsapp
    : `${shareMessages.whatsapp || shareMessages.social}\n${personalReferralUrl}`;
  const shareLinks = {
    whatsapp: `https://wa.me/?text=${encodeURIComponent(whatsappText || shareText)}`,
    telegram: `https://t.me/share/url?url=${encodeURIComponent(personalReferralUrl)}&text=${encodeURIComponent(shareMessages.social)}`,
    facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(personalReferralUrl)}`,
    x: `https://twitter.com/intent/tweet?url=${encodeURIComponent(personalReferralUrl)}&text=${encodeURIComponent(shareMessages.social)}`,
    email: `mailto:?subject=${encodeURIComponent(shareMessages.emailSubject)}&body=${encodeURIComponent(shareMessages.emailBody)}`
  };
  const nativeShareSupported =
    typeof navigator !== "undefined" && typeof navigator.share === "function";
  const locationFields = isGoudhanExperience ? (
    <IndiaLocationFields
      idPrefix="public-signer-location"
      values={{ ...publicLocationForm, address: publicForm.address, country: "India" }}
      onChange={(values) => setPublicForm((current) =>
        applySignerLocationRestriction(
          campaign,
          {
            ...current,
            ...values,
            address: values.address ?? current.address,
            country: "India",
            locationReference: createUnverifiedLocationReference(
              { ...values, country: "India" },
              "public_signer_manual"
            )
          },
          organization
        )
      )}
      locationOverrides={locationOverrides}
      locationDeletions={locationDeletions}
      allowedLocation={publicIndiaAllowedLocation}
      hiddenLockedLevel={signerRestrictionLevel}
      requiredFields={requiredFields}
      labelOverrides={copy.locationLabels}
      fixedCountry="India"
      customLocations={signerLocationCatalog}
      catalogStatus={publicCampaignLocationCatalog.status}
      onPinObservation={(values, postalCode) => setPublicForm((current) => ({
        ...current,
        ...values,
        locationReference: createObservedLocationReference(
          values,
          "public_signer_pin",
          [{ kind: "pin", valueSnapshot: postalCode }]
        )
      }))}
    />
  ) : isGlobalMode ? (
    <GlobalLocationFields
      idPrefix="public-signer-location"
      values={publicLocationForm}
      onChange={(values) => setPublicForm((current) =>
        applySignerLocationRestriction(campaign, {
          ...current,
          ...values,
          locationReference: createUnverifiedLocationReference(values, "public_signer_global_manual")
        }, organization)
      )}
      allowedLocation={lockedLocation}
      hiddenLockedLevel={signerRestrictionLevel}
      requiredFields={requiredFields}
      labelOverrides={copy.locationLabels}
    />
  ) : (
    <IndiaLocationFields
      idPrefix="public-signer-location"
      values={{ ...restrictedPublicForm, address: publicForm.address }}
      onChange={(values) => setPublicForm((current) =>
        applySignerLocationRestriction(campaign, {
          ...current,
          ...values,
          address: values.address ?? current.address,
          locationReference: createUnverifiedLocationReference(values, "public_signer_manual")
        }, organization)
      )}
      locationOverrides={locationOverrides}
      locationDeletions={locationDeletions}
      allowedLocation={publicIndiaAllowedLocation}
      hiddenLockedLevel={signerRestrictionLevel}
      requiredFields={requiredFields}
      labelOverrides={copy.locationLabels}
      customLocations={signerLocationCatalog}
      catalogStatus={publicCampaignLocationCatalog.status}
      onPinObservation={(values, postalCode) => setPublicForm((current) => ({
        ...current,
        ...values,
        locationReference: createObservedLocationReference(
          values,
          "public_signer_pin",
          [{ kind: "pin", valueSnapshot: postalCode }]
        )
      }))}
    />
  );

  useEffect(() => {
    if (!incomingReferralCode) return;
    setPublicForm((current) =>
      current.referredByPhoneOrCode
        ? current
        : { ...current, referredByPhoneOrCode: incomingReferralCode, referralSource: "url" }
    );
  }, [incomingReferralCode, setPublicForm]);

  useEffect(() => {
    if (typeof window === "undefined" || restoredDraftStorageKey === draftStorageKey) return;
    const saved = readPublicSigningDraft(window.sessionStorage, signingCampaignScope);
    if (saved?.form) {
      setPublicForm((current) =>
        clearPublicSigningOtpState({
          ...current,
          ...saved.form
        })
      );
    }
    setWizardStep("phone");
    setCommunicationConsent(false);
    setAppealConsent(false);
    setCampaignConsent(false);
    setRestoredDraftStorageKey(draftStorageKey);
  }, [draftStorageKey, restoredDraftStorageKey, setPublicForm, signingCampaignScope]);

  useEffect(() => {
    if (restoredDraftStorageKey !== draftStorageKey || typeof window === "undefined") return;
    if (hasSignedCampaign) {
      clearPublicSigningJourney(window.sessionStorage, signingCampaignScope);
      return;
    }
    writePublicSigningDraft(window.sessionStorage, signingCampaignScope, publicForm);
  }, [draftStorageKey, restoredDraftStorageKey, hasSignedCampaign, publicForm, signingCampaignScope]);

  useEffect(() => {
    if (!onSaveDraft || !publicForm.otpVerified || !publicForm.otpVerificationToken || hasSignedCampaign) return;
    const timer = window.setTimeout(() => {
      void onSaveDraft();
    }, 700);
    return () => window.clearTimeout(timer);
  }, [
    hasSignedCampaign,
    onSaveDraft,
    publicForm,
    publicForm.otpVerificationToken,
    publicForm.otpVerified
  ]);

  useEffect(() => {
    if (hasSignedCampaign && wizardStep !== "done") {
      setCommunicationConsent(false);
      setAppealConsent(false);
      setCampaignConsent(false);
      setWizardStep("done");
    }
  }, [hasSignedCampaign, wizardStep]);

  useEffect(() => {
    if (previousWizardStepRef.current === wizardStep) return;
    previousWizardStepRef.current = wizardStep;
    const frame = window.requestAnimationFrame(() => stepHeadingRef.current?.focus());
    return () => window.cancelAnimationFrame(frame);
  }, [wizardStep]);

  useEffect(() => {
    if (!publicMessageIsError || !displayPublicMessage) return;
    const frame = window.requestAnimationFrame(() => publicMessageRef.current?.focus());
    return () => window.cancelAnimationFrame(frame);
  }, [displayPublicMessage, publicMessageIsError]);

  useEffect(() => {
    if (!hasSignedCampaign || !lastSignedSigner) return;
    setCoordinatorLocation((current) => {
      if (current.state || current.district || current.block || current.panchayat) return current;
      return {
        country: lastSignedSigner.country || "India",
        state: lastSignedSigner.state || "",
        district: lastSignedSigner.district || "",
        block: lastSignedSigner.block || "",
        panchayat: lastSignedSigner.panchayat || "",
        postalCode: lastSignedSigner.postalCode || ""
      };
    });
    setCoordinatorWard((current) => current || lastSignedSigner.address || "");
  }, [hasSignedCampaign, lastSignedSigner]);

  useEffect(() => {
    if (!movementRequests) return;
    setSavedMovementRequests(movementRequests);
  }, [movementRequests]);

  async function persistMovementRequest(request: ParticipationRequestSubmission) {
    if (!onSubmitMovementRequest || submittingMovementRequest) return;
    const fingerprint = participationRequestFingerprint(request);
    if (movementRequestAttemptRef.current?.fingerprint !== fingerprint) {
      movementRequestAttemptRef.current = {
        fingerprint,
        idempotencyKey: createParticipationRequestIdempotencyKey()
      };
    }
    setSubmittingMovementRequest(true);
    setMovementRequestError("");
    try {
      const saved = await onSubmitMovementRequest(
        request,
        movementRequestAttemptRef.current.idempotencyKey
      );
      setSavedMovementRequests((current) => [
        saved,
        ...current.filter((item) => item.id !== saved.id && item.requestType !== saved.requestType)
      ]);
      movementRequestAttemptRef.current = null;
      window.requestAnimationFrame(() => movementRequestResultRef.current?.focus());
    } catch (error) {
      const code = participationRequestErrorCode(error);
      setMovementRequestError(
        code
          ? `${t(`public.requests.error.${code}`)} (${code})`
          : t("public.requests.retry")
      );
    } finally {
      setSubmittingMovementRequest(false);
    }
  }

  async function submitVolunteerMovementRequest() {
    if (!volunteerConsent) return;
    await persistMovementRequest({
      requestType: "volunteer",
      requestedRole: "volunteer",
      geographicScope: {
        country: lastSignedSigner?.country || "India",
        state: lastSignedSigner?.state || "",
        district: lastSignedSigner?.district || "",
        block: lastSignedSigner?.block || "",
        panchayat: lastSignedSigner?.panchayat || "",
        locationReference: lastSignedSigner?.locationReference ?? null
      },
      skills: parseParticipationRequestList(volunteerSkills),
      areasOfInterest: parseParticipationRequestList(volunteerInterests),
      availability: volunteerAvailability.trim(),
      preferredWorkingArea: volunteerWorkingArea.trim(),
      consent: {
        granted: true,
        version: requestConsentVersion,
        policyId: requestConsentVersion
      }
    });
  }

  async function submitCoordinatorMovementRequest() {
    if (!coordinatorConsent || !coordinatorLocationReady) return;
    await persistMovementRequest({
      requestType: "coordinator",
      requestedRole: "coordinator",
      preferredLevel: coordinatorLevel,
      minimumAcceptableLevel: coordinatorMinimumLevel || undefined,
      geographicScope: {
        country: coordinatorLocation.country || "India",
        state: coordinatorLocation.state,
        district: coordinatorLocation.district,
        block: coordinatorLocation.block,
        panchayat: coordinatorLocation.panchayat,
        ward: coordinatorWard.trim(),
        locationReference: coordinatorLocationReference
      },
      motivation: coordinatorMotivation.trim(),
      experience: coordinatorExperience.trim(),
      availability: coordinatorAvailability.trim(),
      consent: {
        granted: true,
        version: requestConsentVersion,
        policyId: requestConsentVersion
      }
    });
  }

  async function handleSendOtpWizard() {
    if (sendingOtp || supporterRoutingChecking || supporterRoutingError || !phoneReady) return;
    setSendingOtp(true);
    try {
      const sent = await onSendOtp();
      if (sent === false) return;
      setWizardStep("otp");
    } finally {
      setSendingOtp(false);
    }
  }

  async function handleVerifyOtpWizard() {
    if (verifyingOtp) return;
    setVerifyingOtp(true);
    try {
      const outcome = await onVerifyOtp();
      if (outcome === "new_supporter") {
        const route = supporterRoutingPrecheck?.supporterRoute;
        if (route === "existing_account" || route === "historical_signature" || route === "ambiguous") {
          applyVerificationOutcome("secure_access_required");
          return;
        }
        // Do not assume new status if the backend precheck has not completed.
        if (route !== "new_number") {
          setVerificationOutcome("lookup_unavailable");
          return;
        }
      }
      applyVerificationOutcome(outcome);
    } finally {
      setVerifyingOtp(false);
    }
  }

  function applyVerificationOutcome(outcome: PublicSigningVerificationOutcome) {
    if (outcome === "stale") return;
    setVerificationOutcome(outcome);
    if (outcome === "returning_supporter") {
      setReturningSupporterDetected(true);
      setWizardStep("done");
      return;
    }
    if (outcome === "new_supporter") {
      setReturningSupporterDetected(false);
      setWizardStep("profile");
      return;
    }
    if (outcome === "secure_access_required") {
      setParticipationMode("sign_in");
    }
  }

  async function handleRetrySupporterLookup() {
    if (retryingSupporterLookup) return;
    setRetryingSupporterLookup(true);
    try {
      applyVerificationOutcome(await onRetryVerifiedSupporterLookup());
    } finally {
      setRetryingSupporterLookup(false);
    }
  }

  async function handlePublicSubmit(event: FormEvent) {
    if (wizardStep !== "review") {
      event.preventDefault();
      return;
    }
    if (submitting) {
      event.preventDefault();
      return;
    }
    setSubmitting(true);
    try {
      await onSubmit(event);
    } finally {
      setSubmitting(false);
    }
  }

  function handleStartNewJourney() {
    setCommunicationConsent(false);
    setAppealConsent(false);
    setCampaignConsent(false);
    clearSupporterRoutingPrecheck(campaign.id);
    setSupporterRoutingPrecheck(null);
    setVerificationOutcome(null);
    setReturningSupporterDetected(false);
    setRetryingSupporterLookup(false);
    onStartNewJourney();
  }

  async function copyReferralText(
    label: string,
    value: string,
    channel: GrowthShareContext["channel"] = "copy"
  ) {
    try {
      await navigator.clipboard.writeText(value);
      setCopiedReferral(t("public.copied"));
      onGrowthShare?.({ channel, url: value });
    } catch {
      setCopiedReferral(t("public.copyFailed"));
    }
  }

  function trackShareClick(channel: GrowthShareContext["channel"]) {
    onGrowthShare?.({ channel, url: personalReferralUrl });
  }

  function downloadActQr() {
    trackShareClick("qr");
    downloadQrPosterSvg({
      campaign: displayCampaign,
      organizationName: publicOrganizationLabel || "VoiceUp",
      url: personalReferralUrl,
      referralCode: personalReferralCode
    });
  }

  async function shareNatively() {
    if (!navigator.share) return;
    try {
      await navigator.share({
        title: displayCampaign.title,
        text: shareMessages.social,
        url: personalReferralUrl
      });
      trackShareClick("native");
    } catch {
      // Cancellation and browser share failures are intentionally not recorded.
    }
  }

  return (
    <section
      className="public-layout public-campaign-modern public-campaign-v2"
      data-wizard-step={wizardStep}
      data-goudhan-experience={isGoudhanExperience ? "true" : undefined}
      data-gaumata-host={isGaumataCampaignExperience ? "true" : undefined}
      data-premium-presentation={premiumPresentation?.kind}
    >
      <div className="public-page-language-toolbar" aria-label="Language selector">
        <a
          className="public-campaign-sign-in"
          href={campaignAccountAccessPath}
          aria-label={t("account.login.campaignSignIn")}
        >
          <LogIn aria-hidden="true" size={17} />
          <span>{t("account.login.campaignSignIn")}</span>
        </a>
        <LanguageSwitcher />
      </div>
      <div className="public-story-column">
        <article
          className={`public-campaign-v2-hero ${campaignHeroArtwork ? "campaign-page campaign-page-with-media" : "campaign-page"}`}
          style={{
            backgroundImage: displayCampaign.heroImage
              ? !premiumPresentation
                ? `linear-gradient(135deg, rgba(4, 13, 31, 0.82), rgba(4, 13, 31, 0.46)), url(${campaignHeroArtwork})`
                : undefined
              : undefined,
            backgroundPosition: campaign.heroImagePosition,
            backgroundSize: `${campaign.heroImageZoom}%`
          }}
        >
          <div className="public-hero-surface public-campaign-v2-hero-surface">
            <div className="public-campaign-v2-hero-main">
            <div className="public-hero-content">
              {premiumPresentation ? (
                <div className="public-premium-brand" aria-label={publicOrganizationLabel || undefined}>
                  <img
                    src={premiumPresentation.logoAsset}
                    alt={`${displayCampaign.title} logo`}
                  />
                  {isGaumataCampaignExperience && (
                    <small className="public-premium-attribution">{t("goudhanCampaign.poweredByVoiceUp")}</small>
                  )}
                </div>
              ) : isGoudhanExperience ? (
                <div
                  className="goudhan-public-brand public-premium-brand"
                  aria-label={publicOrganizationLabel || undefined}
                >
                  <img
                    src="/brands/gau-samman/campaign-logo.png"
                    alt={`${displayCampaign.title} logo`}
                  />
                  <span>{t("goudhanCampaign.tagline")}</span>
                  {isGaumataCampaignExperience && (
                    <small className="goudhan-powered-by public-premium-attribution">{t("goudhanCampaign.poweredByVoiceUp")}</small>
                  )}
                </div>
              ) : null}
              {!premiumPresentation && (
                <div className="public-hero-kicker">
                  <span className="eyebrow">
                    {isGoudhanExperience
                      ? t("public.movement.publicCampaign")
                      : t("public.verifiedCampaign")}
                  </span>
                  <span className="status-pill" data-status={campaign.status}>{t(`campaignAdmin.status.${campaign.status.toLowerCase()}`)}</span>
                </div>
              )}
              <h1>{displayCampaign.title}</h1>
              {presentationCopy && (
                <p className="public-premium-identity" aria-label={presentationCopy.identityLine}>
                  <span aria-hidden="true" className="public-premium-ornament" />
                  <strong>{presentationCopy.identityLine}</strong>
                  <span aria-hidden="true" className="public-premium-ornament" />
                </p>
              )}
              {presentationCopy && (
                <>
                  <p className="public-premium-subtitle">{presentationCopy.subtitle}</p>
                  <p className="public-premium-invocation">{presentationCopy.invocation}</p>
                </>
              )}
              {!isGoudhanExperience && language !== "en" && <span className="original-language-notice">{t("public.originalLanguageNotice")}</span>}
              {!presentationCopy && <p className="public-summary">{heroSummary}</p>}
              {!premiumPresentation && (
              <div className="public-hero-actions">
                <a className="primary-button" href="#public-sign-form" onClick={() => setParticipationMode("support")}>
                  {isGoudhanExperience ? t("goudhanCampaign.joinMovement") : t("public.signInMinutes")} <ArrowRight size={18} />
                </a>
                {!isGoudhanExperience && nativeShareSupported && (
                  <button className="secondary-button" type="button" onClick={shareNatively}>
                    <Share2 size={18} /> {t("public.shareCampaign")}
                  </button>
                )}
              </div>
              )}
            </div>
            </div>
            {premiumPresentation ? null : (
              <>
            <div className="public-campaign-v2-metrics" aria-label={t("public.supporterCount")}>
              <div className="public-campaign-v2-metric">
                <Users size={16} />
                <span>{t("public.totalSupporters")}</span>
                <strong>{metrics.total.toLocaleString()}</strong>
              </div>
              <div className="public-campaign-v2-metric">
                <BadgeCheck size={16} />
                <span>{t("public.verifiedSupporters")}</span>
                <strong>{metrics.verified.toLocaleString()}</strong>
              </div>
              {metrics.online > 0 && (
                <div className="public-campaign-v2-metric">
                  <Smartphone size={16} />
                  <span>{t("reports.collection.online")}</span>
                  <strong>{metrics.online.toLocaleString()}</strong>
                </div>
              )}
              {metrics.scanned > 0 && (
                <div className="public-campaign-v2-metric">
                  <ClipboardList size={16} />
                  <span>{t("reports.collection.paper")}</span>
                  <strong>{metrics.scanned.toLocaleString()}</strong>
                </div>
              )}
              {(!isGoudhanExperience || configuredCampaignGoal !== null) && (
                <div
                  className="public-campaign-v2-metric public-campaign-v2-metric-progress"
                  aria-label={t("public.campaignProgress")}
                >
                  <span>{t("public.liveProgress")}</span>
                  <strong>{metrics.progress}%</strong>
                  <div className="progress public-progress-bar">
                    <div style={{ width: `${metrics.progress}%` }} />
                  </div>
                  <span className="public-campaign-v2-metric-goal">
                    {t("public.verifiedGoal").replace(
                      "{goal}",
                      (isGoudhanExperience ? configuredCampaignGoal ?? 0 : campaignGoal).toLocaleString()
                    )}
                  </span>
                </div>
              )}
            </div>

            <div className="public-trust-strip" aria-label={t("public.trustIndicators")}>
              <span><ShieldCheck size={16} /> {presentationCopy?.privacyRespect ?? t("public.privacyRespected")}</span>
              <span>
                <LockKeyhole size={16} />{" "}
                {presentationCopy?.verifiedParticipation ?? (isGoudhanExperience ? copy.verificationProtected : t("public.otpVerified"))}
              </span>
              <span>
                {showNeutralAuthority ? <Landmark size={16} /> : <CheckCircle2 size={16} />}
                {presentationCopy?.transparentCampaign ?? (showNeutralAuthority
                  ? t("public.authorityNotConfigured")
                  : isGoudhanExperience
                    ? t("public.movement.authorityConfigured")
                    : t("public.routedToAuthority"))}
              </span>
            </div>
              </>
            )}
          </div>
        </article>

        {premiumPresentation && (
          <div
            className={`public-national-hero-art ${campaignHeroArtwork ? "has-artwork" : "is-awaiting-artwork"}`}
            aria-label={campaignHeroArtwork ? displayCampaign.title : presentationCopy?.heroFallbackLabel}
            role="img"
          >
            {campaignHeroArtwork ? (
              <>
                <img
                  src={campaignHeroArtwork}
                  alt=""
                  fetchPriority="high"
                  decoding="async"
                />
                <div className="public-national-hero-devotional" aria-label="Devotional media block for Gau Samman" >
                  <div className="public-national-hero-devotional-header">
                    <span className="public-national-hero-devotional-title">॥ श्री सुरभ्यै नमः ॥</span>
                    <button
                      type="button"
                      className="public-national-hero-audio-button"
                      onClick={handleMantraToggle}
                      aria-label={audioEnabled ? "Pause mantra audio" : "Play mantra audio"}
                      title={audioEnabled ? "Pause mantra audio" : "Play mantra audio"}
                    >
                      {audioEnabled ? <Volume2 size={14} /> : <VolumeX size={14} />}
                    </button>
                  </div>
                  <video
                    key={monkpujaVideoSources[monkpujaVideoIndex]}
                    className="public-national-hero-video"
                    style={{ height: "clamp(180px, 22vw, 250px)" }}
                    src={monkpujaVideoSources[monkpujaVideoIndex]}
                    title="Gau Samman Ahvaan video"
                    autoPlay
                    muted
                    playsInline
                    controls={false}
                    preload="auto"
                    loop
                    aria-label="Gau Samman Ahvaan video"
                    onEnded={() => setMonkpujaVideoIndex(0)}
                  />
                  <audio
                    ref={mantraAudioRef}
                    src="/assets/sri-surabhyai-namah.mp3"
                    preload="auto"
                    loop
                    aria-label="Mantra audio"
                    onPause={() => setAudioEnabled(false)}
                    onEnded={() => setAudioEnabled(false)}
                    onError={() => setAudioEnabled(false)}
                  />
                  <div className="public-national-hero-youtube-wrap">
                    <div className="public-national-hero-youtube-frame">
                      <video
                        key={panchagavyaVideoSources[panchagavyaVideoIndex]}
                        className="public-national-hero-local-video"
                        src={panchagavyaVideoSources[panchagavyaVideoIndex]}
                        title="Gau Samman Ahvaan video"
                        autoPlay
                        muted
                        playsInline
                        controls={false}
                        preload="auto"
                        aria-label="Gau Samman Ahvaan video"
                        onEnded={() => setPanchagavyaVideoIndex((current) => (current + 1) % panchagavyaVideoSources.length)}
                      />
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div className="public-national-hero-fallback" aria-hidden="true">
                <span className="public-national-hero-halo" />
              </div>
            )}
          </div>
        )}

        {!premiumPresentation && (
          <div className="public-campaign-v2-blank-visual" aria-hidden="true">
            <div className="public-campaign-v2-blank-scene">
              <div className="public-campaign-v2-blank-sun" />
              <div className="public-campaign-v2-blank-diya public-campaign-v2-blank-diya-left" />
              <div className="public-campaign-v2-blank-diya public-campaign-v2-blank-diya-right" />
              <div className="public-campaign-v2-blank-practitioner">
                <div className="public-campaign-v2-blank-head" />
                <div className="public-campaign-v2-blank-robe" />
                <div className="public-campaign-v2-blank-hand public-campaign-v2-blank-hand-left" />
                <div className="public-campaign-v2-blank-hand public-campaign-v2-blank-hand-right" />
              </div>
              <div className="public-campaign-v2-blank-carpet" />
              <div className="public-campaign-v2-blank-chant">॥ श्री सुरभ्यै नमः ॥</div>
            </div>
          </div>
        )}

        {presentationCopy && (
          <GauSammanApprovedContent
            copy={presentationCopy}
            language={language}
            metrics={metrics}
            variant="cards"
          />
        )}

        {!premiumPresentation && (
        <details className="public-campaign-v2-guide">
          <summary className="public-campaign-v2-guide-summary">Campaign Guide</summary>
          <VoiceUpStoryCarousel
            experience="publicCampaign"
            className="voiceup-story-carousel--compact"
            slideIds={["objective", "evidence", "progress", "afterSigning", "share"]}
            mediaBySlide={campaignSupportingArtwork ? { objective: { imageUrl: campaignSupportingArtwork } } : undefined}
            lazyLoadImages
          />
        </details>
        )}

        {isGoudhanExperience && !premiumPresentation && (
          <section className="public-section movement-matters" aria-labelledby="movement-matters-heading">
            <div className="public-section-heading">
              {publicOrganizationLabel && <span className="eyebrow">{publicOrganizationLabel}</span>}
              <h2 id="movement-matters-heading">{presentationCopy?.storyTitle ?? t("public.movement.whyTitle")}</h2>
              <p>{presentationCopy?.storyHelp ?? t("public.movement.whyHelp")}</p>
            </div>
            <div className="movement-matters-grid">
              {movementMatterCards.map((item, index) => (
                <article className={index === 0 ? "movement-matter-card is-featured" : "movement-matter-card"} key={item.title}>
                  {item.icon}
                  <h3>{item.title}</h3>
                  <p>{item.body}</p>
                </article>
              ))}
            </div>
            {presentationCopy && (
              <div className="public-premium-journey" aria-labelledby="premium-journey-heading">
                <h3 id="premium-journey-heading">{presentationCopy.journeyTitle}</h3>
                <ol>
                  {presentationCopy.journeySteps.map((step, index) => (
                    <li key={step}>
                      <span>{String(index + 1).padStart(2, "0")}</span>
                      <strong>{step}</strong>
                    </li>
                  ))}
                </ol>
              </div>
            )}
          </section>
        )}

        {!premiumPresentation && !hasSignedCampaign && (
          <section className="public-section public-share-panel" aria-labelledby="share-campaign-heading">
            <div className="public-section-heading">
              <span className="eyebrow">{t("public.shareThisCampaign")}</span>
              <h2 id="share-campaign-heading">{t("public.shareImpact")}</h2>
            </div>
            <div className="share-panel-grid">
              <div className="share-qr-card">
                <ReferralQrPreview value={personalReferralUrl} label={t("public.campaignQr")} caption={displayCampaign.qrLabel} compact />
                <code>{personalReferralUrl}</code>
                {copiedReferral && <span className="inline-copy-state">{copiedReferral}</span>}
              </div>
              <div className="share-actions-grid">
                <button className="secondary-button" type="button" onClick={() => copyReferralText(t("public.campaignLink"), personalReferralUrl, "copy")}>
                  <Copy size={16} /> {t("public.copyLink")}
                </button>
                {nativeShareSupported && (
                  <button className="secondary-button" type="button" onClick={shareNatively}>
                    <Share2 size={16} /> {t("public.share")}
                  </button>
                )}
                <a className="secondary-link-button" href={shareLinks.whatsapp} target="_blank" rel="noreferrer" onClick={() => trackShareClick("whatsapp")}>WhatsApp</a>
                <a className="secondary-link-button" href={shareLinks.telegram} target="_blank" rel="noreferrer" onClick={() => trackShareClick("telegram")}>Telegram</a>
                <a className="secondary-link-button" href={shareLinks.facebook} target="_blank" rel="noreferrer" onClick={() => trackShareClick("facebook")}>Facebook</a>
                <a className="secondary-link-button" href={shareLinks.email} onClick={() => trackShareClick("email")}><Mail size={16} /> {t("public.email")}</a>
              </div>
            </div>
          </section>
        )}

        {!premiumPresentation && (
        <section className="public-section" aria-labelledby="authority-heading">
          <div className="public-section-heading">
            <span className="eyebrow">{t("public.authorityPath")}</span>
            <h2 id="authority-heading">{t("public.authorityPathHelp")}</h2>
          </div>
          <div className="public-card-grid authority-card-grid">
            {showNeutralAuthority ? (
              <article className="authority-card-modern authority-card-neutral">
                <Landmark size={22} />
                <strong>{t("public.authorityNotConfigured")}</strong>
                <p>{t("public.authorityNotConfiguredHelp")}</p>
              </article>
            ) : (
              authorityCards.map((item) => (
                <article className="authority-card-modern" key={item.id || item.name}>
                  <Landmark size={22} />
                  <span>{item.level}</span>
                  <strong>{item.name}</strong>
                  <p>{formatAuthorityDisplay(item)}</p>
                </article>
              ))
            )}
          </div>
        </section>
        )}

        {!isGoudhanExperience && (
          <section className="public-section" aria-labelledby="story-heading">
            <div className="public-section-heading">
              <span className="eyebrow">{t("public.campaignStory")}</span>
              <h2 id="story-heading">{t("public.campaignStoryHelp")}</h2>
            </div>
            <div className="public-card-grid story-card-grid">
              {storyCards.map((item) => (
                <article className="story-card" key={item.title}>
                  {item.icon}
                  <h3>{item.title}</h3>
                  <p>{item.body}</p>
                </article>
              ))}
            </div>
          </section>
        )}

        {isGoudhanExperience && !premiumPresentation && (
          <section className="public-section movement-media" aria-labelledby="campaign-media-heading">
            <div className="public-section-heading">
              {publicOrganizationLabel && <span className="eyebrow">{publicOrganizationLabel}</span>}
              <h2 id="campaign-media-heading">{t("public.movement.mediaTitle")}</h2>
              <p>{t("public.movement.mediaHelp")}</p>
            </div>
            {hasCampaignMedia ? (
              <div className="movement-media-grid">
                {campaignSupportingArtwork && (
                  <figure className="movement-media-card">
                    <img
                      src={campaignSupportingArtwork}
                      alt={t("public.movement.bannerAlt").replace(
                        "{campaign}",
                        displayCampaign.title
                      )}
                      loading="lazy"
                    />
                  </figure>
                )}
                {youtubeEmbedUrl ? (
                  <div className="movement-video-frame">
                    <iframe
                      src={youtubeEmbedUrl}
                      title={t("public.movement.videoTitle").replace(
                        "{campaign}",
                        displayCampaign.title
                      )}
                      loading="lazy"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                      allowFullScreen
                    />
                  </div>
                ) : campaign.campaignVideoUrl.trim() ? (
                  <a
                    className="secondary-link-button movement-media-link"
                    href={campaign.campaignVideoUrl}
                    target="_blank"
                    rel="noreferrer"
                  >
                    {t("public.movement.openMedia")}
                  </a>
                ) : null}
              </div>
            ) : (
              <p className="public-empty-state">{t("public.movement.noMedia")}</p>
            )}
          </section>
        )}

        {isGoudhanExperience && !premiumPresentation && (
          <section className="public-section goudhan-latest-update" aria-labelledby="latest-updates-heading">
            <div className="public-section-heading">
              {publicOrganizationLabel && <span className="eyebrow">{publicOrganizationLabel}</span>}
              <h2 id="latest-updates-heading">{t("public.movement.updatesTitle")}</h2>
              <p>{t("public.movement.updatesHelp")}</p>
            </div>
            {campaignUpdates.length > 0 ? (
              <div className="movement-update-list">
                {campaignUpdates.map((update, index) => (
                  <article className="movement-update-card" key={`${campaign.id}-update-${index}`}>
                    <p>{update}</p>
                  </article>
                ))}
              </div>
            ) : (
              <p className="public-empty-state">{t("public.movement.noUpdates")}</p>
            )}
          </section>
        )}

        {!premiumPresentation && (
        <section className="public-section" aria-labelledby="faq-heading">
          <div className="public-section-heading">
            <span className="eyebrow">{t("public.faq")}</span>
            <h2 id="faq-heading">{t("public.simpleAnswersBeforeSigning")}</h2>
          </div>
          <div className="faq-list">
            {isGoudhanExperience ? (
              movementFaqItems.map((item) => (
                <details key={item.question}>
                  <summary>{item.question}</summary>
                  <p>{item.answer}</p>
                </details>
              ))
            ) : (
              <>
                <details>
                  <summary>{t("public.howLongSigningTakes")}</summary>
                  <p>{t("public.howLongSigningAnswer")}</p>
                </details>
                <details>
                  <summary>{t("public.whyOtpRequired")}</summary>
                  <p>{t("public.whyOtpRequiredAnswer")}</p>
                </details>
                <details>
                  <summary>{t("public.whatHappensAfterSigning")}</summary>
                  <p>{t("public.whatHappensAfterSigningAnswer")}</p>
                </details>
              </>
            )}
          </div>
        </section>
        )}

        {isGoudhanExperience && !premiumPresentation && (
          <section className="public-section movement-volunteer" aria-labelledby="movement-volunteer-heading">
            <div className="public-section-heading">
              <span className="eyebrow">{t("public.movement.faqVolunteer")}</span>
              <h2 id="movement-volunteer-heading">{t("public.movement.volunteerTitle")}</h2>
              <p>{t("public.movement.volunteerHelp")}</p>
            </div>
            <a
              className="secondary-link-button movement-volunteer-cta"
              href="#public-sign-form"
              onClick={() => {
                setParticipationMode("support");
                if (hasSignedCampaign) setPostSignPanel("coordinator");
              }}
            >
              <Users size={18} /> {t("public.movement.helpOrganise")}
            </a>
          </section>
        )}

        {isGoudhanExperience && !premiumPresentation && movementTrustItems.length > 0 && (
          <section className="public-section movement-trust" aria-labelledby="movement-trust-heading">
            <div className="public-section-heading">
              <span className="eyebrow">{t("public.trustIndicators")}</span>
              <h2 id="movement-trust-heading">{t("public.movement.trustTitle")}</h2>
              <p>{t("public.movement.trustHelp")}</p>
            </div>
            <div className="movement-trust-grid">
              {movementTrustItems.map((item) => (
                <article className="movement-trust-card" key={item.label}>
                  {item.icon}
                  <span>{item.label}</span>
                  {item.href ? <a href={item.href}>{item.value}</a> : <p>{item.value}</p>}
                </article>
              ))}
            </div>
          </section>
        )}

        {!isGoudhanExperience && campaign.campaignVideoUrl && (
          <a className="video-link" href={campaign.campaignVideoUrl} target="_blank" rel="noreferrer">
            {t("public.watchCampaignVideo")}
          </a>
        )}

        {presentationCopy && (
          <GauSammanApprovedContent
            copy={presentationCopy}
            language={language}
            metrics={metrics}
            variant="closing"
            shareLinks={shareLinks}
            onShareClick={trackShareClick}
            lastUpdatedLabel={
              latestSignatureAt
                ? new Date(latestSignatureAt).toLocaleString(requestDateLocale)
                : undefined
            }
          />
        )}
      </div>

      <div className="public-campaign-v2-signing-panel" id="campaign-sign-in">
      <Panel title={hasSignedCampaign ? copy.panelTitleComplete : presentationCopy?.participationTitle ?? copy.panelTitleSign} icon={<ClipboardList />}>
        <div className="public-mobile-campaign-summary">
          <span className="eyebrow">{experienceCopy.campaignAtGlance}</span>
          <strong>{displayCampaign.title}</strong>
          <p>{heroSummary}</p>
          <div className="public-mobile-progress">
            <progress max={100} value={metrics.progress}>{metrics.progress}%</progress>
            <span>{metrics.progress}% · {metrics.verified.toLocaleString()} {t("public.verifiedSupporters")}</span>
          </div>
        </div>
        {!hasSignedCampaign && (
          <div className="campaign-participation-tabs" role="tablist" aria-label={t("account.login.participationMode")}>
            <button
              id="campaign-support-tab"
              type="button"
              role="tab"
              aria-controls="public-sign-form"
              aria-selected={participationMode === "support"}
              onClick={() => setParticipationMode("support")}
            >
              {t("account.login.supportTab")}
            </button>
            <button
              id="campaign-sign-in-tab"
              type="button"
              role="tab"
              aria-controls="campaign-sign-in"
              aria-selected={participationMode === "sign_in"}
              onClick={() => setParticipationMode("sign_in")}
            >
              {t("account.login.campaignSignIn")}
            </button>
          </div>
        )}

        {participationMode === "sign_in" && !hasSignedCampaign ? (
          <div className="public-secure-access-stack">
            {publicMessage === "existing_supporter_duplicate" && (
              <section className="public-secure-access-note" role="status" aria-live="polite">
                <BadgeCheck size={22} aria-hidden="true" />
                <div>
                  <strong>{t("public.alreadySigned")}</strong>
                  <p>{t("public.existingSupporterDuplicate")}</p>
                  <p>{t("public.alreadySignedHelp")}</p>
                  <a href={shareLinks.whatsapp} target="_blank" rel="noopener noreferrer" onClick={() => trackShareClick("whatsapp")}>{t("public.shareCampaign")}</a>
                </div>
              </section>
            )}
            {verificationOutcome === "secure_access_required" && publicMessage !== "existing_supporter_duplicate" && (
              <section className="public-secure-access-note" role="status">
                <ShieldCheck size={22} aria-hidden="true" />
                <div>
                  <strong>{t("public.returning.secureTitle")}</strong>
                  <p>{t("public.returning.secureHelp")}</p>
                </div>
              </section>
            )}
            <CampaignInlineAuthPanel
              active
              context={{ campaignId: campaign.id, campaignSlug: campaign.slug }}
              routingToken={supporterRoutingPrecheck?.routingToken}
              initialRoute={supporterRoutingPrecheck?.supporterRoute}
              onContinueSigning={() => {
                setVerificationOutcome(null);
                setParticipationMode("support");
                setWizardStep("profile");
              }}
            />
          </div>
        ) : (
        <>
        <div className="wizard-header">
          <span className="eyebrow">{copy.secureSigning}</span>
          <h2>{hasSignedCampaign ? copy.headerComplete : presentationCopy?.participationTitle ?? copy.headerActive}</h2>
          {presentationCopy && !hasSignedCampaign && <strong>{presentationCopy.participationTime}</strong>}
          <p>{copy.headerHelp}</p>
          {!hasSignedCampaign && (
            <p className="public-step-progress" aria-live="polite">{stepProgressLabel}</p>
          )}
        </div>

        {publicVerificationComplete && !hasSignedCampaign && (
          <div className="verified-welcome" aria-live="polite">
            <UserRound size={20} />
            <div>
              <strong>{copy.phoneVerified}</strong>
              <span>
                {publicForm.verificationMethod === "screen_otp"
                  ? copy.verificationCompleteBody
                  : t("public.welcomeBack")}
              </span>
            </div>
          </div>
        )}

        {!publicVerificationComplete &&
          !hasSignedCampaign &&
          wizardStep !== "phone" &&
          wizardStep !== "otp" && (
            <div className="public-verification-recovery" role="alert">
              <ShieldCheck size={20} aria-hidden="true" />
              <div>
                <strong>{t("public.verificationRecoveryTitle")}</strong>
                <span>{t("public.verificationRecoveryHelp")}</span>
              </div>
              <button className="secondary-button" type="button" onClick={() => setWizardStep("phone")}>
                {t("public.verifyAgain")}
              </button>
            </div>
          )}

        <ol className="wizard-steps" aria-label={t("public.signingSteps")}>
          {activeSigningSteps.map((step, index) => (
            <li key={step.id} aria-current={index === activeStepIndex ? "step" : undefined}>
              <div
                className={index === activeStepIndex ? "wizard-step is-active" : index < activeStepIndex ? "wizard-step is-complete" : "wizard-step"}
              >
                <span>{index + 1}</span>
                {step.id === "review" ? t("public.review") : copy.steps[step.id]}
              </div>
            </li>
          ))}
        </ol>

        <form
          id="public-sign-form"
          className="form-stack public-sign-form public-sign-wizard"
          aria-busy={sendingOtp || verifyingOtp || submitting}
          onSubmit={handlePublicSubmit}
        >
          <span className="sr-only" aria-live="polite">
            {sendingOtp
              ? experienceCopy.otpSending
              : verifyingOtp
                ? experienceCopy.otpVerifying
                : submitting
                  ? experienceCopy.submitWorking
                  : ""}
          </span>
          <p className="required-note">* {t("public.required")}</p>
          {incomingReferralCode && (
            <div className="referral-invite-note">
              <Share2 size={18} />
              <div>
                <strong>
                  {copy.invitedBy} {incomingReferrer ? getSafeReferrerLabel(incomingReferrer) : copy.invitedFallback}.
                </strong>
                <span>{copy.referralOptional}</span>
              </div>
            </div>
          )}

          {wizardStep === "phone" && (
            <div className="wizard-body">
              <div className="wizard-copy">
                <Smartphone size={22} />
                <h3 ref={stepHeadingRef} tabIndex={-1}>{copy.phoneTitle}</h3>
                <p id="public-phone-help">{copy.phoneHelp}</p>
              </div>
              <Field label={premiumPresentation ? `${presentationCopy?.phoneLabel ?? t("public.phone")} *` : signerFieldLabel(t("public.phone"), "phone")}>
                <div className={premiumPresentation ? "public-india-phone-input" : undefined}>
                  {premiumPresentation && (
                    <span aria-hidden="true">+91</span>
                  )}
                  <input
                  aria-label={presentationCopy?.phoneLabel ?? t("public.phone")}
                  aria-describedby="public-phone-help public-phone-validation"
                  aria-invalid={showPhoneError}
                  placeholder={premiumPresentation ? "98765 43210" : t("public.phone")}
                  value={premiumPresentation ? indianMobile.display : publicForm.phone}
                  inputMode="tel"
                  autoComplete="tel"
                  maxLength={premiumPresentation ? INDIAN_MOBILE_INPUT_MAX_LENGTH : undefined}
                  required
                  onChange={(event) => {
                    const phone = premiumPresentation
                      ? normalizeIndianMobileInput(event.target.value).canonical
                      : event.target.value;
                    if (publicForm.phone === phone) return;
                    if (!shouldStartNewJourneyForPhoneInput(publicForm.phone, phone, publicForm)) {
                      setPublicForm({ ...publicForm, phone });
                      return;
                    }
                    handleStartNewJourney();
                    setPublicForm({
                      ...blankSigner,
                      name: publicForm.name,
                      phone,
                      referredByPhoneOrCode: publicForm.referredByPhoneOrCode,
                      referralSource: publicForm.referralSource
                    });
                  }}
                />
                </div>
              </Field>
              <p
                id="public-phone-validation"
                className={showPhoneError ? "public-validation-hint is-error" : "public-validation-hint"}
                role={showPhoneError ? "alert" : undefined}
              >
                {presentationCopy
                  ? showPhoneError
                    ? presentationCopy.phoneInvalid
                    : indianMobile.complete
                      ? presentationCopy.phoneHint
                      : presentationCopy.phoneIncomplete
                  : t("public.phoneValidation")}
              </p>
              <button className="primary-button" type="button" disabled={sendingOtp || supporterRoutingChecking || supporterRoutingError || !phoneReady} aria-busy={sendingOtp || supporterRoutingChecking} onClick={() => void handleSendOtpWizard()}>
                {sendingOtp ? experienceCopy.otpSending : (isGoudhanExperience ? copy.requestVerification : t("public.sendOtp"))} <ArrowRight size={18} />
              </button>
              {supporterRoutingChecking && (
                <p className="info-message" role="status" aria-live="polite">
                  {t("account.login.checking")}
                </p>
              )}
              {supporterRoutingError && (
                <div className="public-phone-check-error" role="alert">
                  <p className="error-message">{t("public.phoneCheckFailed")}</p>
                  <button
                    className="secondary-button"
                    type="button"
                    onClick={() => setSupporterRoutingAttempt((current) => current + 1)}
                  >
                    {t("public.retryPhoneCheck")}
                  </button>
                </div>
              )}
              {otpMessage && (
                <p
                  className={otpMessageIsError ? "error-message" : "info-message"}
                  role={otpMessageIsError ? "alert" : "status"}
                  aria-live={otpMessageIsError ? "assertive" : "polite"}
                >
                  {!otpMessageIsError && /^Verification code:\s*(\d{6})$/.test(safeOtpMessage.trim()) ? (
                    <span className="public-signing-verification-code">
                      <span>
                        <strong>{safeOtpMessage.trim().match(/\d{6}$/)?.[0]}</strong>
                      </span>
                      <button
                        type="button"
                        aria-label="Copy verification code"
                        onClick={() => {
                          const code = safeOtpMessage.trim().match(/\d{6}$/)?.[0];
                          if (code) void navigator.clipboard.writeText(code);
                        }}
                      >
                        Copy code
                      </button>
                    </span>
                  ) : safeOtpMessage}
                </p>
              )}
            </div>
          )}

          {wizardStep === "otp" && (
            <div className="wizard-body">
              <div className="wizard-copy">
                <LockKeyhole size={22} />
                <h3 ref={stepHeadingRef} tabIndex={-1}>{copy.otpTitle}</h3>
                <p id="public-otp-help">{copy.otpHelp}</p>
              </div>
              <div className="otp-box">
                <input
                  aria-label={t("public.enterOtp")}
                  aria-describedby="public-otp-help public-otp-validation"
                  aria-invalid={Boolean(otpInput.trim()) && !otpReady}
                  placeholder={t("public.enterOtp")}
                  value={otpInput}
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  maxLength={6}
                  pattern="[0-9]{6}"
                  required
                  onChange={(event) => setOtpInput(event.target.value.replace(/\D/g, "").slice(0, 6))}
                />
                <p
                  id="public-otp-validation"
                  className={otpInput.trim() && !otpReady ? "public-validation-hint is-error" : "public-validation-hint"}
                >
                  {t("public.otpValidation")}
                </p>
                <div className="button-row">
                  <button
                    className="secondary-button"
                    type="button"
                    onClick={() => {
                      handleStartNewJourney();
                      setWizardStep("phone");
                    }}
                  >
                    {t("public.changePhone")}
                  </button>
                  <button className="secondary-button" type="button" disabled={sendingOtp} onClick={() => void handleSendOtpWizard()}>
                    {sendingOtp ? experienceCopy.otpSending : copy.resendOtp}
                  </button>
                  <button className="primary-button" type="button" disabled={verifyingOtp || !otpReady} aria-busy={verifyingOtp} onClick={() => void handleVerifyOtpWizard()}>
                    {verifyingOtp ? experienceCopy.otpVerifying : (isGoudhanExperience ? copy.verifyCode : t("public.verifyOtp"))}
                  </button>
                </div>
                {publicVerificationComplete && <span className="status-pill">{copy.phoneVerified}</span>}
                {otpMessage && (
                  <p
                    className={otpMessageIsError ? "error-message" : "info-message"}
                    role={otpMessageIsError ? "alert" : "status"}
                    aria-live={otpMessageIsError ? "assertive" : "polite"}
                  >
                    {!otpMessageIsError && /^Verification code:\s*(\d{6})$/.test(safeOtpMessage.trim()) ? (
                    <span className="public-signing-verification-code">
                      <span>
                        <strong>{safeOtpMessage.trim().match(/\d{6}$/)?.[0]}</strong>
                      </span>
                      <button
                        type="button"
                        aria-label="Copy verification code"
                        onClick={() => {
                          const code = safeOtpMessage.trim().match(/\d{6}$/)?.[0];
                          if (code) void navigator.clipboard.writeText(code);
                        }}
                      >
                        Copy code
                      </button>
                    </span>
                  ) : safeOtpMessage}
                  </p>
                )}

                {verificationOutcome === "lookup_unavailable" && (
                  <section className="public-supporter-lookup-state" role="alert">
                    <ShieldCheck size={20} aria-hidden="true" />
                    <div>
                      <strong>{t("public.returning.lookupTitle")}</strong>
                      <p>{t("public.returning.lookupHelp")}</p>
                      <button
                        className="secondary-button"
                        type="button"
                        disabled={retryingSupporterLookup}
                        aria-busy={retryingSupporterLookup}
                        onClick={() => void handleRetrySupporterLookup()}
                      >
                        {retryingSupporterLookup
                          ? t("public.returning.lookupWorking")
                          : t("public.returning.retryLookup")}
                      </button>
                    </div>
                  </section>
                )}
              </div>
            </div>
          )}

          {wizardStep === "profile" && (
            <div className="wizard-body">
              <div className="wizard-copy">
                <UserRound size={22} />
                <h3 ref={stepHeadingRef} tabIndex={-1}>{copy.profileTitle}</h3>
                <p>{copy.profileHelp}</p>
              </div>
              <Field label={signerFieldLabel(t("public.name"), "name")}>
                <input
                  aria-label={t("public.name")}
                  placeholder={t("public.name")}
                  value={publicForm.name}
                  required={isRequired("name")}
                  onChange={(event) => setPublicForm({ ...publicForm, name: event.target.value })}
                />
              </Field>
              {emailRequired && (
                <Field label={`${copy.emailLabel} *`}>
                  <input
                    aria-label={copy.emailLabel}
                    placeholder={copy.emailPlaceholder}
                    type="email"
                    value={publicForm.email}
                    required
                    onChange={(event) => setPublicForm({ ...publicForm, email: event.target.value })}
                  />
                </Field>
              )}
              {campaign.authoritySelectionMode === "public_choice" && (
                <Field label={copy.authorityLabel}>
                  <select
                    value={publicForm.selectedAuthorityId || publicAuthorityOptions[0]?.id || ""}
                    onChange={(event) => {
                      const selected = publicAuthorityOptions.find((item) => item.id === event.target.value);
                      setPublicForm({
                        ...publicForm,
                        selectedAuthorityId: event.target.value,
                        selectedAuthorityName: selected?.name ?? ""
                      });
                    }}
                  >
                    {publicAuthorityOptions.map((option) => (
                      <option key={option.id} value={option.id}>
                        {formatAuthorityDisplay(option)}
                      </option>
                    ))}
                  </select>
                </Field>
              )}
              <div className="wizard-actions">
                <button className="secondary-button" type="button" onClick={() => setWizardStep("otp")}>{t("public.back")}</button>
                {!detailsRequired && (
                  <button className="secondary-button" type="button" onClick={() => setWizardStep("address")}>{copy.addOptionalDetails}</button>
                )}
                <button className="primary-button" type="button" disabled={!profileReady} onClick={() => setWizardStep(detailsRequired ? "address" : "review")}>{t("public.continue")} <ArrowRight size={18} /></button>
              </div>
              {!profileReady && <p className="public-validation-hint">{t("public.completeRequiredFields")}</p>}
            </div>
          )}

          {wizardStep === "address" && (
            <div className="wizard-body">
              <div className="wizard-copy">
                <MapPin size={22} />
                <h3 ref={stepHeadingRef} tabIndex={-1}>{copy.detailsTitle}</h3>
                <p>{copy.detailsHelp}</p>
              </div>
              <div className="public-smart-location">
                <div>
                  <strong>{locationSectionTitle}</strong>
                  <span>{locationSectionHelp}</span>
                </div>
                <PublicCampaignCanonicalLocationDisplay
                  campaignSlug={campaign.slug}
                  values={{
                    country: publicLocationForm.country || campaign.country || (isGlobalMode ? "" : "India"),
                    state: publicLocationForm.state,
                    district: publicLocationForm.district,
                    block: publicLocationForm.block,
                    panchayat: publicLocationForm.panchayat
                  }}
                  campaignPolicy={signerLocationCatalog}
                  transport={invokePublicCampaignLocationCatalog}
                  title={experienceCopy.structuredLocationTitle}
                  help={experienceCopy.structuredLocationHelp}
                  labels={locationLabels}
                  unavailableMessage={t("public.canonicalLocationUnavailable")}
                  onConfirmCanonicalReference={(locationReference) =>
                    setPublicForm((current) => ({ ...current, locationReference }))
                  }
                />
              </div>
              {(restrictionMessage || locationRequired) && (
                <div className="public-location-limit" aria-live="polite">
                  <MapPin size={18} aria-hidden="true" />
                  <div>
                    <strong>{copy.locationLimitTitle}</strong>
                    {lockedLocationParts.length > 0 ? (
                      <ul>
                        {lockedLocationParts.map((location) => (
                          <li key={location}>{location}</li>
                        ))}
                      </ul>
                    ) : (
                      <p>{restrictionMessage}</p>
                    )}
                  </div>
                </div>
              )}
              {(restrictionMessage || locationRequired) && locationFields}
              {!restrictionMessage && !locationRequired && locationFields}
              {isGlobalMode && !isGoudhanExperience && (
                <Field label={isRequired("address") ? signerFieldLabel(addressLabel, "address") : addressLabel}>
                  <input
                    aria-label={addressLabel}
                    placeholder={addressPlaceholder}
                    value={publicForm.address}
                    required={isRequired("address")}
                    onChange={(event) => setPublicForm({ ...publicForm, address: event.target.value })}
                  />
                </Field>
              )}
              <details className="optional-details">
                <summary>{copy.optionalDetails}</summary>
                {!emailRequired && (
                  <Field label={`${copy.emailLabel} (${t("public.optional")})`}>
                    <input
                      aria-label={copy.emailLabel}
                      placeholder={copy.emailPlaceholder}
                      type="email"
                      value={publicForm.email}
                      onChange={(event) => setPublicForm({ ...publicForm, email: event.target.value })}
                    />
                  </Field>
                )}
                <Field label={copy.whatsappLabel}>
                  <input
                    aria-label={copy.whatsappLabel}
                    placeholder={copy.whatsappPlaceholder}
                    value={publicForm.whatsappNumber}
                    onChange={(event) => setPublicForm({ ...publicForm, whatsappNumber: event.target.value })}
                  />
                </Field>
                <Field label={copy.telegramLabel}>
                  <input
                    aria-label={copy.telegramLabel}
                    placeholder={copy.telegramPlaceholder}
                    value={publicForm.telegramHandle}
                    onChange={(event) => setPublicForm({ ...publicForm, telegramHandle: event.target.value })}
                  />
                </Field>
                <Field label={copy.referralLabel}>
                  <input
                    aria-label={copy.referralLabel}
                    placeholder={t("public.optional")}
                    value={publicForm.referredByPhoneOrCode ?? ""}
                    onChange={(event) =>
                      setPublicForm({
                        ...publicForm,
                        referredByPhoneOrCode: event.target.value,
                        referralSource: event.target.value.trim() ? "manual" : undefined
                      })
                    }
                  />
                  <small>{copy.referralHelp}</small>
                  {typedReferral && (
                    <small role="status" aria-live="polite">
                      {typedReferrer
                        ? isSelfReferral
                          ? "You cannot refer yourself."
                          : `Referring supporter: ${getSafeReferrerLabel(typedReferrer)}. Confirm this is the correct person.`
                        : "Referral not confirmed in currently loaded campaign records. Do not submit until verified."}
                    </small>
                  )}
                </Field>
              </details>
              <div className="wizard-actions">
                <button className="secondary-button" type="button" onClick={() => setWizardStep("profile")}>{t("public.back")}</button>
                <button className="primary-button" type="button" disabled={!detailsReady} onClick={() => setWizardStep("review")}>{t("public.review")} <ArrowRight size={18} /></button>
              </div>
              {!detailsReady && <p className="public-validation-hint">{t("public.completeRequiredFields")}</p>}
            </div>
          )}

          {wizardStep === "review" && (
            <div className="wizard-body">
              <div className="wizard-copy">
                <ClipboardList size={22} />
                <h3 ref={stepHeadingRef} tabIndex={-1}>{copy.reviewTitle}</h3>
                <p>{copy.reviewHelp}</p>
              </div>
              <div className="review-card">
                <span>{t("public.name")} <strong>{publicForm.name || copy.notEntered}</strong></span>
                <span>
                  {t("public.phone")}{" "}
                  <strong>
                    {publicForm.phone
                      ? premiumPresentation
                        ? `+91 ${indianMobile.display}`
                        : publicForm.phone
                      : copy.notEntered}
                  </strong>
                </span>
                {publicForm.state.trim() ? (
                  <span>{copy.locationLabels.state} <strong>{publicForm.state}</strong></span>
                ) : null}
                {publicForm.district.trim() ? (
                  <span>{copy.locationLabels.district} <strong>{publicForm.district}</strong></span>
                ) : null}
                {publicForm.block.trim() ? (
                  <span>{copy.locationLabels.block} <strong>{publicForm.block}</strong></span>
                ) : null}
                {publicForm.panchayat.trim() ? (
                  <span>{copy.locationLabels.panchayat} <strong>{publicForm.panchayat}</strong></span>
                ) : null}
                <span>
                  {copy.reviewAuthority}{" "}
                  <strong>
                    {showNeutralAuthority
                      ? t("public.authorityNotConfigured")
                      : publicForm.selectedAuthorityName || resolvedAuthority.name}
                  </strong>
                </span>
                <span>{copy.reviewReferral} <strong>{publicForm.referredByPhoneOrCode || copy.none}</strong></span>
              </div>
              <div className="trust-section" aria-label={copy.trustLabel}>
                <span><ShieldCheck size={18} /> {copy.privacyRespected}</span>
                <span><LockKeyhole size={18} /> {copy.storedSecurely}</span>
                <span>
                  {showNeutralAuthority ? <Landmark size={18} /> : <CheckCircle2 size={18} />}
                  {showNeutralAuthority ? t("public.authorityNotConfigured") : copy.routedAuthority}
                </span>
              </div>
              <fieldset className="public-consent-group">
                <legend>{t("public.consentChoices")}</legend>
                <label className="check-row">
                  <input required type="checkbox"
                    name="supportAppealConsent"
                    checked={appealConsent}
                    onChange={(event) => setAppealConsent(event.target.checked)}
                  />
                  <span><strong>{t("public.required")}</strong>{copy.supportCheckbox}</span>
                </label>
                <label className="check-row">
                  <input required type="checkbox"
                    name="campaignConsent"
                    checked={campaignConsent}
                    onChange={(event) => setCampaignConsent(event.target.checked)}
                  />
                  <span><strong>{t("public.required")}</strong>{displayCampaign.consentText}</span>
                </label>
                <label className="check-row">
                  <input
                    type="checkbox"
                    name="campaignCommunicationConsent"
                    checked={communicationConsent}
                    onChange={(event) => {
                      const granted = event.target.checked;
                      setCommunicationConsent(granted);
                      void onCommunicationConsentChange?.(granted);
                    }}
                  />
                  <span><strong>{t("public.optional")}</strong>{t("public.communicationConsentHelp")}</span>
                </label>
              </fieldset>
              <div className="wizard-actions">
                <button className="secondary-button" type="button" onClick={() => setWizardStep(detailsRequired || hasOptionalDetails ? "address" : "profile")}>{t("public.back")}</button>
                <button className="primary-button" type="submit" disabled={submitting || !requiredConsentsAccepted} aria-busy={submitting}>
                  <CheckCircle2 size={18} /> {submitting ? experienceCopy.submitWorking : t("public.submitSupport")}
                </button>
              </div>
              {!requiredConsentsAccepted && (
                <p className="public-validation-hint">{t("public.acceptRequiredConsents")}</p>
              )}
            </div>
          )}

          {wizardStep === "done" && hasSignedCampaign && returningSupporterDetected && (
            <div className="wizard-body public-returning-supporter">
              <section aria-labelledby="public-returning-supporter-heading">
                <div className="public-returning-mark" aria-hidden="true">
                  <BadgeCheck size={34} />
                </div>
                <span className="eyebrow">{t("public.returning.eyebrow")}</span>
                <h3 id="public-returning-supporter-heading" ref={stepHeadingRef} tabIndex={-1}>
                  {t("public.returning.title")}
                </h3>
                <strong>{t("public.returning.recorded")}</strong>
                <p>{t("public.returning.help")}</p>
                <div className="public-returning-actions">
                  <a
                    className="primary-link-button"
                    href={linkedSupporterAccount
                      ? `/account/supporter/${encodeURIComponent(linkedSupporterAccount.accountId)}`
                      : campaignAccountAccessPath}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <LogIn size={18} />
                    {linkedSupporterAccount
                      ? t("public.returning.dashboard")
                      : t("public.returning.secureAccess")}
                  </a>
                  <a
                    className="secondary-link-button"
                    href={shareLinks.whatsapp}
                    target="_blank"
                    rel="noreferrer"
                    onClick={() => trackShareClick("whatsapp")}
                  >
                    <Share2 size={18} /> {t("public.returning.share")}
                  </a>
                </div>
                <p className="public-returning-privacy">
                  <ShieldCheck size={16} aria-hidden="true" />
                  {t("public.returning.privacy")}
                </p>
              </section>
            </div>
          )}

          {wizardStep === "done" && hasSignedCampaign && !returningSupporterDetected && (
            <div className="wizard-body done-card">
              {isGoudhanExperience ? (
                <>
                  <section
                    className="public-premium-success"
                    aria-labelledby="public-premium-success-heading"
                  >
                    <div className="public-success-mark" aria-hidden="true">
                      <CheckCircle2 size={32} />
                    </div>
                    <span className="eyebrow">{t("public.success.supportVerified")}</span>
                    <h3
                      id="public-premium-success-heading"
                      ref={stepHeadingRef}
                      tabIndex={-1}
                    >
                      {lastSignedSigner?.name
                        ? `${t("public.thankYou")}, ${lastSignedSigner.name}`
                        : t("public.thankYou")}
                    </h3>
                    <p>{t("public.success.recorded")}</p>
                    <p>
                      {t("public.success.verifiedSupporterOf")} {displayCampaign.title}.
                    </p>
                    <strong>{t("public.success.partOfMovement")}</strong>
                    <dl className="public-success-facts">
                      {lastSignedSigner?.name && (
                        <div>
                          <dt>{t("public.success.supporterName")}</dt>
                          <dd>{lastSignedSigner.name}</dd>
                        </div>
                      )}
                      {lastSignedSigner?.id && (
                        <div>
                          <dt>{t("public.success.supporterId")}</dt>
                          <dd><code>{lastSignedSigner.id}</code></dd>
                        </div>
                      )}
                      <div>
                        <dt>{t("public.success.campaign")}</dt>
                        <dd>{displayCampaign.title}</dd>
                      </div>
                      <div>
                        <dt>{t("public.success.supporterCount")}</dt>
                        <dd>{metrics.total.toLocaleString()}</dd>
                      </div>
                      {configuredCampaignGoal !== null && (
                        <div>
                          <dt>{t("public.success.campaignProgress")}</dt>
                          <dd>{metrics.progress}%</dd>
                        </div>
                      )}
                    </dl>
                  </section>

                  <section className="public-celebration" aria-labelledby="public-celebration-heading">
                    <HeartHandshake size={26} aria-hidden="true" />
                    <div>
                      <h4 id="public-celebration-heading">{t("public.success.welcome")}</h4>
                      <p>{displayCampaign.thankYouMessage}</p>
                      <span>{t("goudhanCampaign.tagline")}</span>
                    </div>
                  </section>
                </>
              ) : (
                <>
                  <CheckCircle2 size={28} />
                  <h3 ref={stepHeadingRef} tabIndex={-1}>
                    {lastSignedSigner?.name
                      ? `${t("public.thankYou")}, ${lastSignedSigner.name}`
                      : t("public.thankYou")}
                  </h3>
                  <p>{copy.doneBody}</p>
                  <p>
                    {t("public.success.verifiedSupporterOf")} {displayCampaign.title}.
                  </p>
                </>
              )}

              <section className="public-post-sign-next" aria-labelledby="public-campaign-journey-heading">
                <div className="public-section-heading">
                  <span className="eyebrow">{t("public.success.journeyReadyTitle")}</span>
                  <h4 id="public-campaign-journey-heading">{t("public.success.journeyReadyHelp")}</h4>
                </div>
                {personalReferralCode ? (
                  <>
                    <a
                      className="primary-link-button"
                      href={`/r/${encodeURIComponent(personalReferralCode)}`}
                    >
                      <ArrowRight size={18} /> {t("public.success.viewJourney")}
                    </a>
                    <p>
                      {t("public.success.supporterCode")}
                      <br />
                      <code>{personalReferralCode}</code>
                    </p>
                  </>
                ) : null}
                <p>{t("public.success.returnLater")}</p>
              </section>

              {lastSignedSigner &&
                onSupporterAccountLinked &&
                (supporterAccountClaimGrant || linkedSupporterAccount) && (
                  <SupporterAccountClaimPanel
                    grant={supporterAccountClaimGrant}
                    linkedAccount={linkedSupporterAccount}
                    campaignId={campaign.id}
                    campaignSlug={campaign.slug}
                    campaignTitle={displayCampaign.title}
                    supporterId={lastSignedSigner.id}
                    supporterName={lastSignedSigner.name}
                    supporterEmail={lastSignedSigner.email}
                    onLinked={onSupporterAccountLinked}
                    copy={{
                      eyebrow: t("public.success.account.eyebrow"),
                      title: t("public.success.account.title"),
                      help: t("public.success.account.help"),
                      email: t("public.success.account.email"),
                      password: t("public.success.account.password"),
                      showPassword: t("public.success.account.showPassword"),
                      hidePassword: t("public.success.account.hidePassword"),
                      register: t("public.success.account.register"),
                      loginAndClaim: t("public.success.account.loginAndClaim"),
                      claim: t("public.success.account.claim"),
                      useAnotherAccount: t("public.success.account.useAnotherAccount"),
                      registrationSent: t("public.success.account.registrationSent"),
                      signedInAs: t("public.success.account.signedInAs"),
                      signingEmail: t("public.success.account.signingEmail"),
                      accountEmail: t("public.success.account.accountEmail"),
                      emailMismatch: t("public.success.account.emailMismatch"),
                      linkedTitle: t("public.success.account.linkedTitle"),
                      linkedHelp: t("public.success.account.linkedHelp"),
                      profileName: t("public.success.account.profileName"),
                      supporterId: t("public.success.account.supporterId"),
                      campaign: t("public.success.account.campaign"),
                      openProfile: t("public.success.account.openProfile"),
                      working: t("public.success.account.working"),
                      authFailed: t("public.success.account.authFailed"),
                      confirmationRequired: t("public.success.account.confirmationRequired"),
                      claimInvalid: t("public.success.account.claimInvalid"),
                      claimExpired: t("public.success.account.claimExpired"),
                      claimFailed: t("public.success.account.claimFailed"),
                      skip: t("public.success.account.skip"),
                      openingDashboard: t("public.success.account.openingDashboard"),
                      forgotPassword: t("account.login.forgotPassword"),
                      recoverySent: t("account.login.recoverySent"),
                      recoveryFailed: t("account.login.recoveryFailed")
                    }}
                  />
                )}

              <section className="public-post-sign-sharing" aria-label={t("public.shareThisCampaign")}>
                <div className="public-section-heading">
                  <span className="eyebrow">{t("public.success.shareMySupport")}</span>
                  <h4>{t("public.success.inviteOthers")}</h4>
                  <p>{t("public.success.personalLinkHelp")}</p>
                </div>
                <ReferralQrPreview
                  value={personalReferralUrl}
                  label={t("public.campaignQr")}
                  caption={displayCampaign.qrLabel}
                  compact
                />
                <code className="public-personal-referral-url">{personalReferralUrl}</code>
                <div className="public-post-sign-actions">
                  <a
                    className="secondary-link-button"
                    href={shareLinks.whatsapp}
                    target="_blank"
                    rel="noreferrer"
                    onClick={() => trackShareClick("whatsapp")}
                  >
                    <MessageCircle size={18} /> WhatsApp
                  </a>
                  <a
                    className="secondary-link-button"
                    href={shareLinks.facebook}
                    target="_blank"
                    rel="noreferrer"
                    onClick={() => trackShareClick("facebook")}
                  >
                    Facebook
                  </a>
                  <a
                    className="secondary-link-button"
                    href={shareLinks.x}
                    target="_blank"
                    rel="noreferrer"
                    onClick={() => trackShareClick("x")}
                  >
                    X
                  </a>
                  <a
                    className="secondary-link-button"
                    href={shareLinks.telegram}
                    target="_blank"
                    rel="noreferrer"
                    onClick={() => trackShareClick("telegram")}
                  >
                    Telegram
                  </a>
                  {nativeShareSupported && (
                    <button className="secondary-button" type="button" onClick={shareNatively}>
                      <Share2 size={18} /> {t("referrals.dashboard.nativeShare")}
                    </button>
                  )}
                  <button
                    className="secondary-button"
                    type="button"
                    onClick={() => void copyReferralText(t("public.referralLink"), personalReferralUrl, "copy")}
                  >
                    <Copy size={18} /> {t("public.success.copyReferralLink")}
                  </button>
                  <button className="secondary-button" type="button" onClick={downloadActQr}>
                    <QrCode size={18} /> {t("public.campaignQr")}
                  </button>
                </div>
                {copiedReferral && <span className="public-share-status" role="status">{copiedReferral}</span>}
              </section>

              {isGoudhanExperience && personalReferralCode && (
                <a className="secondary-link-button public-supporter-profile-link" href={`/r/${encodeURIComponent(personalReferralCode)}`}>
                  <UserRound size={18} /> {t("goudhanCampaign.myProfile")}
                </a>
              )}

              {isGoudhanExperience &&
                onUploadSupporterPhoto &&
                !lastSignedSigner?.profilePhotoPath &&
                !photoPanelDismissed && (
                  <PublicSupporterPhoto
                    copy={experienceCopy.photo}
                    onUpload={async (file) => {
                      await onUploadSupporterPhoto(file);
                      setPhotoPanelDismissed(true);
                    }}
                    onSkip={() => setPhotoPanelDismissed(true)}
                  />
                )}

              {isGoudhanExperience && lastSignedSigner?.profilePhotoPath && (
                <p className="success-message" role="status">{t("goudhanCampaign.photoSaved")}</p>
              )}

              {isGoudhanExperience && onSubmitMovementRequest && (
                <section
                  className="public-movement-requests"
                  aria-labelledby="public-movement-requests-heading"
                >
                  <div className="public-section-heading">
                    <span className="eyebrow">{t("public.requests.getInvolved")}</span>
                    <h4 id="public-movement-requests-heading">
                      {t("public.requests.choosePath")}
                    </h4>
                    <p>{t("public.requests.reviewOnly")}</p>
                  </div>
                  <div className="public-involvement-options">
                    <article>
                      <UserRound size={20} />
                      <strong>{t("public.success.continueSupporter")}</strong>
                      <p>{t("public.success.continueSupporterHelp")}</p>
                      {personalReferralCode ? (
                        <a
                          className="secondary-link-button"
                          href={`/r/${encodeURIComponent(personalReferralCode)}`}
                        >
                          {t("goudhanCampaign.myProfile")}
                        </a>
                      ) : (
                        <span className="public-request-muted">
                          {t("public.success.supportRecorded")}
                        </span>
                      )}
                    </article>
                    <article>
                      <HeartHandshake size={20} />
                      <strong>{t("public.requests.volunteerTitle")}</strong>
                      <p>{t("public.requests.volunteerHelp")}</p>
                      <button
                        className="secondary-button"
                        type="button"
                        aria-expanded={postSignPanel === "volunteer"}
                        onClick={() => {
                          setMovementRequestError("");
                          setPostSignPanel((current) =>
                            current === "volunteer" ? "none" : "volunteer"
                          );
                        }}
                      >
                        {t("public.requests.applyVolunteer")}
                      </button>
                    </article>
                    <article>
                      <Users size={20} />
                      <strong>{t("public.requests.coordinatorTitle")}</strong>
                      <p>{t("public.requests.coordinatorHelp")}</p>
                      <button
                        className="secondary-button"
                        type="button"
                        aria-expanded={postSignPanel === "coordinator"}
                        onClick={() => {
                          setMovementRequestError("");
                          setPostSignPanel((current) =>
                            current === "coordinator" ? "none" : "coordinator"
                          );
                        }}
                      >
                        {t("public.requests.applyCoordinator")}
                      </button>
                    </article>
                  </div>

                  {savedMovementRequest && (
                    <div className="public-request-result success-message" role="status">
                      <CheckCircle2 size={20} />
                      <h5 ref={movementRequestResultRef} tabIndex={-1}>
                        {savedMovementRequest.requestType === "volunteer"
                          ? t("public.requests.volunteerSubmitted")
                          : t("public.requests.coordinatorSubmitted")}
                      </h5>
                      <span>
                        {t("public.requests.requestId")}: <code>{savedMovementRequest.id}</code>
                      </span>
                      <span>
                        {t("public.requests.currentStatus")}:{" "}
                        {t(`public.requests.status.${savedMovementRequest.status}`)}
                      </span>
                      {savedMovementRequest.requestType === "coordinator" && (
                        <>
                          <span>
                            {t("public.requests.preferredLevel")}:{" "}
                            {savedMovementRequest.preferredLevel
                              ? t(`public.requests.level.${savedMovementRequest.preferredLevel}`)
                              : t("public.requests.noMinimum")}
                          </span>
                          <span>
                            {t("public.requests.minimumLevel")}:{" "}
                            {savedMovementRequest.minimumAcceptableLevel
                              ? t(`public.requests.level.${savedMovementRequest.minimumAcceptableLevel}`)
                              : t("public.requests.noMinimum")}
                          </span>
                          <span>
                            {t("public.requests.geographicArea")}:{" "}
                            {formatParticipationRequestGeography(savedMovementRequest)}
                          </span>
                          {savedMovementRequest.preferredLevel && (
                            <p>
                              {t(`public.requests.responsibility.${savedMovementRequest.preferredLevel}`)}
                            </p>
                          )}
                        </>
                      )}
                      <p>{t("public.requests.pendingReview")}</p>
                    </div>
                  )}

                  {movementRequestError && (
                    <p className="error-message" role="alert">{movementRequestError}</p>
                  )}

                  {postSignPanel === "volunteer" && (
                    <div className="public-request-form" aria-labelledby="volunteer-request-heading">
                      <h5 id="volunteer-request-heading">{t("public.requests.volunteerForm")}</h5>
                      <Field label={t("public.requests.skills")}>
                        <input
                          value={volunteerSkills}
                          placeholder={t("public.requests.listPlaceholder")}
                          onChange={(event) => setVolunteerSkills(event.target.value)}
                        />
                      </Field>
                      <Field label={t("public.requests.interests")}>
                        <input
                          value={volunteerInterests}
                          placeholder={t("public.requests.listPlaceholder")}
                          onChange={(event) => setVolunteerInterests(event.target.value)}
                        />
                      </Field>
                      <Field label={t("public.requests.availability")}>
                        <input
                          value={volunteerAvailability}
                          onChange={(event) => setVolunteerAvailability(event.target.value)}
                        />
                      </Field>
                      <Field label={t("public.requests.preferredWorkingArea")}>
                        <input
                          value={volunteerWorkingArea}
                          onChange={(event) => setVolunteerWorkingArea(event.target.value)}
                        />
                      </Field>
                      <label className="check-row">
                        <input
                          type="checkbox"
                          checked={volunteerConsent}
                          onChange={(event) => setVolunteerConsent(event.target.checked)}
                        />
                        <span>
                          <strong>{t("public.required")}</strong>
                          {t("public.requests.consent")} {displayCampaign.consentText}
                        </span>
                      </label>
                      <button
                        className="primary-button"
                        type="button"
                        disabled={!volunteerConsent || submittingMovementRequest}
                        aria-busy={submittingMovementRequest}
                        onClick={() => void submitVolunteerMovementRequest()}
                      >
                        {submittingMovementRequest
                          ? t("public.requests.submitting")
                          : t("public.requests.submitVolunteer")}
                      </button>
                    </div>
                  )}

                  {postSignPanel === "coordinator" && (
                    <div className="public-request-form" aria-labelledby="coordinator-request-heading">
                      <h5 id="coordinator-request-heading">{t("public.requests.coordinatorForm")}</h5>
                      <Field label={t("public.requests.preferredLevel")}>
                        <select
                          value={coordinatorLevel}
                          onChange={(event) => {
                            const level = event.target.value as ParticipationRequestLevel;
                            setCoordinatorLevel(level);
                            if (
                              coordinatorMinimumLevel
                              && !getMinimumParticipationLevels(level).includes(coordinatorMinimumLevel)
                            ) {
                              setCoordinatorMinimumLevel("");
                            }
                          }}
                        >
                          {PARTICIPATION_REQUEST_LEVELS.map((level) => (
                            <option value={level} key={level}>
                              {t(`public.requests.level.${level}`)}
                            </option>
                          ))}
                        </select>
                      </Field>
                      <p className="public-request-responsibility" role="status">
                        {t(`public.requests.responsibility.${coordinatorLevel}`)}
                      </p>
                      <Field label={t("public.requests.minimumLevel")}>
                        <select
                          value={coordinatorMinimumLevel}
                          onChange={(event) =>
                            setCoordinatorMinimumLevel(
                              event.target.value as ParticipationRequestLevel | ""
                            )
                          }
                        >
                          <option value="">{t("public.requests.noMinimum")}</option>
                          {minimumCoordinatorLevels.map((level) => (
                            <option value={level} key={level}>
                              {t(`public.requests.level.${level}`)}
                            </option>
                          ))}
                        </select>
                      </Field>
                      <div className="public-request-geography">
                        <strong>{t("public.requests.geographicArea")}</strong>
                        <IndiaLocationFields
                          idPrefix="public-coordinator-request"
                          values={coordinatorLocation}
                          onChange={(values) => {
                            setCoordinatorLocation(values);
                            setCoordinatorLocationReference(createUnverifiedLocationReference(
                              { ...values, ward: coordinatorWard },
                              "public_coordinator_manual"
                            ));
                          }}
                          locationOverrides={locationOverrides}
                          locationDeletions={locationDeletions}
                          requiredFields={coordinatorRequiredFields}
                          labelOverrides={copy.locationLabels}
                          customLocations={signerLocationCatalog}
                          catalogStatus={publicCampaignLocationCatalog.status}
                          onPinObservation={(values, postalCode) => {
                            setCoordinatorLocation(values);
                            setCoordinatorLocationReference(createObservedLocationReference(
                              { ...values, ward: coordinatorWard },
                              "public_coordinator_pin",
                              [{ kind: "pin", valueSnapshot: postalCode }]
                            ));
                          }}
                        />
                        <PublicCampaignCanonicalLocationDisplay
                          campaignSlug={campaign.slug}
                          values={{ ...coordinatorLocation, country: "India" }}
                          campaignPolicy={signerLocationCatalog}
                          transport={invokePublicCampaignLocationCatalog}
                          title={experienceCopy.structuredLocationTitle}
                          help={experienceCopy.structuredLocationHelp}
                          labels={locationLabels}
                          unavailableMessage={t("public.canonicalLocationUnavailable")}
                          onConfirmCanonicalReference={setCoordinatorLocationReference}
                        />
                        {coordinatorLevel === "ward" && (
                          <Field label={`${t("public.requests.villageWard")} *`}>
                            <input
                              required
                              value={coordinatorWard}
                              onChange={(event) => {
                                setCoordinatorWard(event.target.value);
                                setCoordinatorLocationReference(createUnverifiedLocationReference(
                                  { ...coordinatorLocation, ward: event.target.value },
                                  "public_coordinator_manual"
                                ));
                              }}
                            />
                          </Field>
                        )}
                      </div>
                      <Field label={t("public.requests.experience")}>
                        <textarea
                          value={coordinatorExperience}
                          onChange={(event) => setCoordinatorExperience(event.target.value)}
                        />
                      </Field>
                      <Field label={t("public.requests.motivation")}>
                        <textarea
                          value={coordinatorMotivation}
                          onChange={(event) => setCoordinatorMotivation(event.target.value)}
                        />
                      </Field>
                      <Field label={t("public.requests.availability")}>
                        <input
                          value={coordinatorAvailability}
                          onChange={(event) => setCoordinatorAvailability(event.target.value)}
                        />
                      </Field>
                      <label className="check-row">
                        <input
                          type="checkbox"
                          checked={coordinatorConsent}
                          onChange={(event) => setCoordinatorConsent(event.target.checked)}
                        />
                        <span>
                          <strong>{t("public.required")}</strong>
                          {t("public.requests.consent")} {displayCampaign.consentText}
                        </span>
                      </label>
                      {!coordinatorLocationReady && (
                        <p className="public-validation-hint">
                          {t("public.requests.completeGeography")}
                        </p>
                      )}
                      <button
                        className="primary-button"
                        type="button"
                        disabled={
                          !coordinatorConsent
                          || !coordinatorLocationReady
                          || submittingMovementRequest
                        }
                        aria-busy={submittingMovementRequest}
                        onClick={() => void submitCoordinatorMovementRequest()}
                      >
                        {submittingMovementRequest
                          ? t("public.requests.submitting")
                          : t("public.requests.submitCoordinator")}
                      </button>
                    </div>
                  )}
                </section>
              )}

              {isGoudhanExperience
                && (movementRequestsLoading || movementRequestsError || savedMovementRequests.length > 0)
                && (
                <section
                  className="public-request-tracker"
                  aria-labelledby="public-request-tracker-heading"
                >
                  <div className="public-section-heading">
                    <div>
                      <span className="eyebrow">{t("public.success.trackRequest")}</span>
                      <h4 id="public-request-tracker-heading">
                        {t("public.success.myRequests")}
                      </h4>
                    </div>
                    {onRefreshMovementRequests && (
                      <button
                        className="secondary-button"
                        type="button"
                        disabled={movementRequestsLoading}
                        aria-busy={movementRequestsLoading}
                        onClick={() => void onRefreshMovementRequests()}
                      >
                        {t("public.success.refreshRequests")}
                      </button>
                    )}
                  </div>
                  {movementRequestsLoading && (
                    <p className="public-request-loading" role="status" aria-live="polite">
                      {t("public.success.loadingRequests")}
                    </p>
                  )}
                  {movementRequestsError && !movementRequestsLoading && (
                    <p className="error-message" role="alert">
                      {movementRequestsError === "otp_verification_required"
                        ? t("public.success.requestReadVerificationRequired")
                        : t("public.success.requestReadFailed")}
                    </p>
                  )}
                  <div className="public-request-tracker-list">
                    {savedMovementRequests.map((request) => {
                      return (
                        <article key={request.id} className="public-request-tracker-card">
                          <div>
                            <strong>
                              {request.requestType === "volunteer"
                                ? t("public.requests.volunteerTitle")
                                : t("public.requests.coordinatorTitle")}
                            </strong>
                            <span className="status-pill" data-status={request.status}>
                              {t(`public.requests.status.${request.status}`)}
                            </span>
                          </div>
                          <dl>
                            <div>
                              <dt>{t("public.requests.requestId")}</dt>
                              <dd><code>{request.id}</code></dd>
                            </div>
                            <div>
                              <dt>{t("public.success.requestType")}</dt>
                              <dd>
                                {request.requestType === "volunteer"
                                  ? t("public.requests.volunteerTitle")
                                  : t("public.requests.coordinatorTitle")}
                              </dd>
                            </div>
                            <div>
                              <dt>{t("public.success.submittedTime")}</dt>
                              <dd>{new Date(request.submittedAt).toLocaleString(requestDateLocale)}</dd>
                            </div>
                            <div>
                              <dt>{t("public.success.campaign")}</dt>
                              <dd>{request.campaign.title}</dd>
                            </div>
                            <div>
                              <dt>{t("public.success.currentStage")}</dt>
                              <dd>{t(`public.success.stage.${request.currentStage}`)}</dd>
                            </div>
                            <div>
                              <dt>{t("public.success.lastUpdated")}</dt>
                              <dd>{new Date(request.updatedAt).toLocaleString(requestDateLocale)}</dd>
                            </div>
                            {request.requestType === "coordinator" && request.preferredLevel && (
                              <>
                                <div>
                                  <dt>{t("public.requests.preferredLevel")}</dt>
                                  <dd>{t(`public.requests.level.${request.preferredLevel}`)}</dd>
                                </div>
                                <div>
                                  <dt>{t("public.requests.minimumLevel")}</dt>
                                  <dd>
                                    {request.minimumAcceptableLevel
                                      ? t(`public.requests.level.${request.minimumAcceptableLevel}`)
                                      : t("public.requests.noMinimum")}
                                  </dd>
                                </div>
                                <div>
                                  <dt>{t("public.requests.geographicArea")}</dt>
                                  <dd>{formatParticipationRequestGeography(request)}</dd>
                                </div>
                              </>
                            )}
                          </dl>
                        </article>
                      );
                    })}
                  </div>
                </section>
              )}

              {isGoudhanExperience && (
                <section className="public-movement-dashboard-entry">
                  <button
                    className="secondary-button"
                    type="button"
                    aria-expanded={showMovementDashboard}
                    aria-controls="public-movement-dashboard"
                    onClick={() => setShowMovementDashboard((current) => !current)}
                  >
                    <UserRound size={18} /> {t("public.success.movementDashboard")}
                  </button>
                  {showMovementDashboard && (
                    <div
                      id="public-movement-dashboard"
                      className="public-movement-dashboard"
                      aria-label={t("public.success.movementDashboard")}
                    >
                      <article>
                        <CheckCircle2 size={20} />
                        <strong>{t("public.success.mySupport")}</strong>
                        <span>{displayCampaign.title}</span>
                        {lastSignedSigner?.id && <code>{lastSignedSigner.id}</code>}
                      </article>
                      <article>
                        <ClipboardList size={20} />
                        <strong>{t("public.success.myRequests")}</strong>
                        <span>
                          {movementRequestsLoading
                            ? t("public.success.loadingRequests")
                            : savedMovementRequests.length > 0
                            ? String(savedMovementRequests.length)
                            : t("public.success.noRequests")}
                        </span>
                        {movementRequestsError && !movementRequestsLoading && (
                          <span className="error-message" role="alert">
                            {movementRequestsError === "otp_verification_required"
                              ? t("public.success.requestReadVerificationRequired")
                              : t("public.success.requestReadFailed")}
                          </span>
                        )}
                        {onRefreshMovementRequests && (
                          <button
                            className="secondary-button"
                            type="button"
                            disabled={movementRequestsLoading}
                            onClick={() => void onRefreshMovementRequests()}
                          >
                            {t("public.success.refreshRequests")}
                          </button>
                        )}
                      </article>
                      <article>
                        <QrCode size={20} />
                        <strong>{t("public.success.myReferralLink")}</strong>
                        <code>{personalReferralUrl}</code>
                        <button
                          className="secondary-button"
                          type="button"
                          onClick={() =>
                            void copyReferralText(
                              t("public.referralLink"),
                              personalReferralUrl,
                              "copy"
                            )
                          }
                        >
                          <Copy size={16} /> {t("public.copyLink")}
                        </button>
                      </article>
                      <article>
                        <Share2 size={20} />
                        <strong>{t("public.success.mySharedLinks")}</strong>
                        <div className="public-dashboard-share-links">
                          <a href={shareLinks.whatsapp} target="_blank" rel="noreferrer" onClick={() => trackShareClick("whatsapp")}>WhatsApp</a>
                          <a href={shareLinks.facebook} target="_blank" rel="noreferrer" onClick={() => trackShareClick("facebook")}>Facebook</a>
                          <a href={shareLinks.x} target="_blank" rel="noreferrer" onClick={() => trackShareClick("x")}>X</a>
                          <a href={shareLinks.telegram} target="_blank" rel="noreferrer" onClick={() => trackShareClick("telegram")}>Telegram</a>
                        </div>
                      </article>
                    </div>
                  )}
                </section>
              )}

              {(!isGoudhanExperience || !onSubmitMovementRequest) && (
                <button
                  className="secondary-button public-coordinator-action"
                  type="button"
                  onClick={() => setPostSignPanel((current) => current === "coordinator" ? "none" : "coordinator")}
                >
                  <Users size={18} /> {experienceCopy.becomeCoordinator}
                </button>
              )}

              {(!isGoudhanExperience || !onSubmitMovementRequest) && postSignPanel === "coordinator" && (
                <div className="public-coordinator-handoff">
                  <h4>{experienceCopy.helpOrganise}</h4>
                  <p>{experienceCopy.coordinatorHandoff}</p>
                  {coordinatorLearnMore && <p>{experienceCopy.coordinatorLearn}</p>}
                  <div className="button-row">
                    <button
                      className="secondary-button"
                      type="button"
                      onClick={() => setCoordinatorLearnMore((value) => !value)}
                    >
                      {experienceCopy.learnMore}
                    </button>
                    {onSubmitCoordinatorApplication ? (
                      <button
                        className="primary-button"
                        type="button"
                        disabled={lastSignedSigner?.coordinatorApplication?.status === "Pending Approval"}
                        onClick={() => void onSubmitCoordinatorApplication()}
                      >
                        <Mail size={18} /> {
                          lastSignedSigner?.coordinatorApplication?.status === "Pending Approval"
                            ? experienceCopy.coordinatorPending
                            : experienceCopy.coordinatorContact
                        }
                      </button>
                    ) : (
                      <a
                        className="primary-link-button"
                        href={`mailto:${campaign.adminEmail}?subject=${encodeURIComponent(
                          `${experienceCopy.becomeCoordinator}: ${displayCampaign.title}`
                        )}&body=${encodeURIComponent(
                          t("goudhanCampaign.coordinatorRequestBody")
                        )}`}
                      >
                        <Mail size={18} /> {experienceCopy.coordinatorContact}
                      </a>
                    )}
                  </div>
                </div>
              )}
              {campaign.donationEnabled && <DonationCard campaign={campaign} compact />}
            </div>
          )}

          {displayPublicMessage && (
            <p
              ref={publicMessageRef}
              tabIndex={publicMessageIsError ? -1 : undefined}
              className={publicMessageIsError ? "error-message" : "success-message"}
              role={publicMessageIsError ? "alert" : "status"}
              aria-live={publicMessageIsError ? "assertive" : "polite"}
            >
              {displayPublicMessage}
              {publicMessage === "existing_supporter_duplicate" && (
                <>
                  {" "}
                  <a
                    className="primary-link-button"
                    href={shareLinks.whatsapp}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => trackShareClick("whatsapp")}
                  >
                    <Share2 size={16} /> {t("public.shareCampaign")}
                  </a>
                </>
              )}
            </p>
          )}
        </form>
        </>
        )}
        {premiumPresentation && !hasSignedCampaign && (
          <div className="public-mobile-trust-progress">
            <div className="public-mobile-trust-row">
              <span><LockKeyhole size={16} /> {presentationCopy?.verifiedParticipation}</span>
              <span><ShieldCheck size={16} /> {presentationCopy?.privacyRespect}</span>
              <span><BadgeCheck size={16} /> {presentationCopy?.transparentCampaign}</span>
              <span><Users size={16} /> {presentationCopy?.publicCollaboration}</span>
            </div>
            {premiumVisibleMetrics.length > 0 && (
              <div className="public-campaign-v2-metrics" aria-label={t("public.supporterCount")}>
                {premiumVisibleMetrics.map((metric) => (
                  <div className="public-campaign-v2-metric" key={`mobile-${metric.key}`}>
                    <span>{metric.label}</span>
                    <strong>{metric.value.toLocaleString()}</strong>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
        {presentationCopy && (
          <p className="public-premium-privacy-footer">
            <LockKeyhole size={14} /> {presentationCopy.privacyFooter}
          </p>
        )}
        {!hasSignedCampaign && (
          <div className="public-sign-share-tools" aria-label={t("public.shareThisCampaign")}>
            <ReferralQrPreview value={personalReferralUrl} label={t("public.campaignQr")} caption={displayCampaign.qrLabel} compact />
            <div>
              {nativeShareSupported && (
                <button className="secondary-button" type="button" onClick={shareNatively}>
                  <Share2 size={17} /> {t("public.share")}
                </button>
              )}
              <a className="secondary-link-button" href={shareLinks.whatsapp} target="_blank" rel="noreferrer" onClick={() => trackShareClick("whatsapp")}>
                WhatsApp
              </a>
              <button
                className="secondary-button"
                type="button"
                onClick={() => void copyReferralText(t("public.campaignLink"), personalReferralUrl, "copy")}
              >
                <Copy size={17} /> {t("public.copyLink")}
              </button>
            </div>
            {copiedReferral && <span className="public-share-status" role="status">{copiedReferral}</span>}
          </div>
        )}
      </Panel>
      </div>

      {!hasSignedCampaign && (
        <a className="sticky-support-button" href="#public-sign-form" onClick={() => setParticipationMode("support")}>
          <CheckCircle2 size={18} />{" "}
          {isGaumataCampaignExperience
            ? t("goudhanCampaign.joinMovement")
            : t("public.supportCampaign")}
        </a>
      )}
    </section>
  );
}

export function PublicCampaignNotFound({ onRetry }: { onRetry?: () => void }) {
  const { t } = useTranslation();
  return (
    <main className="public-only-shell">
      <section className="empty-state public-not-found">
        <span className="eyebrow">{t("public.notFound.eyebrow")}</span>
        <h1>{t("public.notFound.title")}</h1>
        <p>{t("public.notFound.description")}</p>
        <div className="button-row">
          <button
            className="primary-button"
            type="button"
            onClick={onRetry ?? (() => window.location.reload())}
          >
            {t("public.notFound.retry")}
          </button>
          <a className="secondary-link-button" href="/">
            {t("public.notFound.home")}
          </a>
        </div>
      </section>
    </main>
  );
}

export function PublicCampaignLoading({ message }: { message: string }) {
  const { t } = useTranslation();
  return (
    <main className="public-only-shell">
      <section className="empty-state public-not-found">
        <span className="eyebrow">{t("public.loading.eyebrow")}</span>
        <h1>{t("public.loading.title")}</h1>
        <p>{message}</p>
      </section>
    </main>
  );
}
