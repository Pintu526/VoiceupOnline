import {
  GOUDHAN_CAMPAIGN_SLUG,
  isGaumataPublicHostname
} from "../config/goudhanProduction.ts";

const GAUMATA_ROOT_CAMPAIGN_SLUG = GOUDHAN_CAMPAIGN_SLUG;

export interface PublicCampaignRouteLocation {
  pathname: string;
  hostname: string;
}

export function resolvePublicCampaignSlug({
  pathname,
  hostname
}: PublicCampaignRouteLocation): string {
  const directCampaignSlug = pathname.match(/^\/c\/([^/]+)\/?$/)?.[1] ?? "";
  if (directCampaignSlug) return directCampaignSlug;
  if ((pathname === "/" || pathname === "") && isGaumataPublicHostname(hostname)) {
    return GAUMATA_ROOT_CAMPAIGN_SLUG;
  }
  return "";
}

export function getPublicCampaignSlug(): string {
  if (typeof window === "undefined") return "";
  return resolvePublicCampaignSlug({
    pathname: window.location.pathname,
    hostname: window.location.hostname
  });
}

export function getSupporterPortalCode(): string {
  if (typeof window === "undefined") return "";
  return window.location.pathname.match(/^\/r\/([^/]+)\/?$/)?.[1] ?? "";
}

export function getCampaignAdminSlug(): string {
  if (typeof window === "undefined") return "";
  const slug = window.location.pathname.match(/^\/admin\/([^/]+)\/?$/)?.[1] ?? "";
  return slug === "reset-password" ? "" : slug;
}

export function getIsSaasAdminRoute(): boolean {
  if (typeof window === "undefined") return false;
  return window.location.pathname === "/admin" || window.location.pathname === "/admin/";
}

export function getIsSaasAdminPasswordResetRoute(): boolean {
  if (typeof window === "undefined") return false;
  return (
    window.location.pathname === "/admin/reset-password"
    || window.location.pathname === "/admin/reset-password/"
  );
}

export function getIsAppRoute(): boolean {
  if (typeof window === "undefined") return false;
  return window.location.pathname === "/app" || window.location.pathname.startsWith("/app/");
}

export function getIsVoiceupLoginRoute(): boolean {
  if (typeof window === "undefined") return false;
  return window.location.pathname === "/login" || window.location.pathname === "/login/";
}

export function getSupporterAccountDashboardId(): string {
  if (typeof window === "undefined") return "";
  return window.location.pathname.match(
    /^\/account\/supporter\/([0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})\/?$/i
  )?.[1] ?? "";
}

export function getIsVoiceupAccountRoute(): boolean {
  if (typeof window === "undefined") return false;
  return window.location.pathname === "/account"
    || window.location.pathname === "/account/"
    || Boolean(getSupporterAccountDashboardId());
}

export interface CertificateVerificationRoute {
  certificateId: string;
  verificationReference: string;
}

export function getCertificateVerificationRoute(): CertificateVerificationRoute | null {
  if (typeof window === "undefined") return null;
  const certificateId = window.location.pathname.match(/^\/certificates\/verify\/([A-Za-z0-9_-]{3,120})\/?$/)?.[1] ?? "";
  const verificationReference = new URLSearchParams(window.location.search).get("ref")?.trim() ?? "";
  return certificateId ? { certificateId, verificationReference } : null;
}

export function getLegalPage(): "privacy" | "terms" | "refund" | "data-deletion" | null {
  if (typeof window === "undefined") return null;
  const path = window.location.pathname.replace(/^\//, "");
  if (
    path === "privacy" ||
    path === "terms" ||
    path === "refund" ||
    path === "data-deletion"
  ) {
    return path as "privacy" | "terms" | "refund" | "data-deletion";
  }
  return null;
}

export function getIsLandingPageRoute(): boolean {
  if (typeof window === "undefined") return false;
  const pathname = window.location.pathname;
  return pathname === "/" || pathname === "";
}

export function getIsCampaignOsRoute(): boolean {
  if (typeof window === "undefined") return false;
  return window.location.pathname.replace(/\/$/, "").toLowerCase() === "/campaignos";
}

export function getIsStartRoute(): boolean {
  if (typeof window === "undefined") return false;
  return window.location.pathname === "/start" || window.location.pathname === "/start/";
}
