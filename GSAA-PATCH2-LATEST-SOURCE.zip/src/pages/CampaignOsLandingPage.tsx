import { motion } from "framer-motion";
import {
  ArrowRight,
  BadgeCheck,
  BarChart3,
  Bot,
  BriefcaseBusiness,
  CheckCircle2,
  FileCheck2,
  Globe2,
  HandCoins,
  HeartHandshake,
  LayoutDashboard,
  Megaphone,
  Network,
  QrCode,
  ScanLine,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  UsersRound,
  type LucideIcon
} from "lucide-react";
import { useState } from "react";
import {
  campaignReadinessLabels,
  campaignShowcaseCopy,
  campaignShowcaseModules,
  campaignShowcaseTracks,
  type CampaignReadinessStatus,
  type CampaignShowcaseModule,
  type CampaignShowcaseTrack
} from "../campaignShowcaseCatalog";
import { campaignCapabilityAssessments } from "../campaignCompletion";
import { GOUDHAN_CAMPAIGN_SLUG } from "../config/goudhanProduction";
import { LanguageSwitcher, useTranslation } from "../i18n";

const pillarIcons: Record<CampaignShowcaseTrack, LucideIcon> = {
  organize: UsersRound,
  plan: BriefcaseBusiness,
  act: Megaphone,
  fund: HandCoins,
  prove: FileCheck2,
  grow: TrendingUp,
  businessOs: ShieldCheck
};

const moduleIcons: Record<string, LucideIcon> = {
  "organizations-workspaces": LayoutDashboard,
  "volunteers-coordinators": Network,
  "roles-permissions": ShieldCheck,
  "resources-locations": Globe2,
  "campaign-lifecycle": Megaphone,
  "campaign-settings-branding": Sparkles,
  "six-step-signing": CheckCircle2,
  "otp-verification": BadgeCheck,
  "field-collection": ScanLine,
  "paper-signature-scanning": ScanLine,
  "qr-whatsapp-social": QrCode,
  "progress-analytics": BarChart3,
  "shared-reporting": BarChart3,
  "ai-copilot": Bot,
  "merchant-partner-foundations": HeartHandshake
};

const pillarDestinations: Partial<Record<CampaignShowcaseTrack, string>> = {
  organize: "/app?tab=coordinators",
  plan: "/app?tab=campaigns",
  act: "/app?tab=public",
  prove: "/app?tab=reports",
  grow: "/app?tab=growth"
};

const availability: Record<CampaignReadinessStatus, { label: string; className: string }> = {
  completed: { label: "Operational", className: "operational" },
  pendingFinalReview: { label: "Development", className: "development" },
  inProgress: { label: "Development", className: "development" },
  notStarted: { label: "Planned", className: "planned" },
  blocked: { label: "Planned", className: "planned" }
};

const supplementalCapabilities: ReadonlyArray<CampaignShowcaseModule> = [
  {
    id: "command-center-overview",
    track: "businessOs",
    title: { en: "Campaign Command Center & overview", hi: "अभियान कमांड सेंटर और अवलोकन", or: "ଅଭିଯାନ କମାଣ୍ଡ ସେଣ୍ଟର୍ ଏବଂ ସାରାଂଶ" },
    description: { en: "Movement health, risk, action priorities and campaign operating context in one workspace view.", hi: "एक कार्यक्षेत्र दृश्य में अभियान स्वास्थ्य, जोखिम, कार्य प्राथमिकताएँ और संचालन संदर्भ।", or: "ଗୋଟିଏ କାର୍ଯ୍ୟକ୍ଷେତ୍ର ଦୃଶ୍ୟରେ ଅଭିଯାନ ସ୍ୱାସ୍ଥ୍ୟ, ବିପଦ, କାର୍ଯ୍ୟ ପ୍ରାଥମିକତା ଏବଂ ପରିଚାଳନା ପ୍ରସଙ୍ଗ।" },
    status: "pendingFinalReview",
    tab: "command"
  },
  {
    id: "participation-certificates",
    track: "prove",
    title: { en: "Participation certificates & designer", hi: "भागीदारी प्रमाणपत्र और डिज़ाइनर", or: "ଅଂଶଗ୍ରହଣ ପ୍ରମାଣପତ୍ର ଏବଂ ଡିଜାଇନର୍" },
    description: { en: "Campaign certificate configuration, preview, issuance, supporter access and public verification foundations.", hi: "अभियान प्रमाणपत्र कॉन्फ़िगरेशन, पूर्वावलोकन, जारी करना, समर्थक पहुँच और सार्वजनिक सत्यापन आधार।", or: "ଅଭିଯାନ ପ୍ରମାଣପତ୍ର ବିନ୍ୟାସ, ପୂର୍ବଦର୍ଶନ, ପ୍ରଦାନ, ସମର୍ଥକ ପ୍ରବେଶ ଏବଂ ସାର୍ବଜନୀନ ଯାଞ୍ଚ ଭିତ୍ତିଭୂମି।" },
    status: "pendingFinalReview",
    tab: "campaigns"
  },
  {
    id: "merchant-partner-foundations",
    track: "grow",
    title: { en: "Merchant & partner reward foundations", hi: "व्यापारी और भागीदार पुरस्कार आधार", or: "ବ୍ୟବସାୟୀ ଏବଂ ସହଭାଗୀ ପୁରସ୍କାର ଭିତ୍ତିଭୂମି" },
    description: { en: "Growth configuration, merchant records, reward catalogs and redemption service foundations under development.", hi: "विकासाधीन ग्रोथ कॉन्फ़िगरेशन, व्यापारी रिकॉर्ड, पुरस्कार कैटलॉग और रिडेम्पशन सेवा आधार।", or: "ବିକାଶାଧୀନ ଗ୍ରୋଥ୍ ବିନ୍ୟାସ, ବ୍ୟବସାୟୀ ରେକର୍ଡ, ପୁରସ୍କାର କ୍ୟାଟାଲଗ୍ ଏବଂ ରିଡେମ୍ପସନ୍ ସେବା ଭିତ୍ତିଭୂମି।" },
    status: "inProgress",
    tab: "growth"
  }
];

function moduleHref(moduleId: string, tab?: string, action?: string) {
  if (moduleId === "gsaa-public-campaign") return `/c/${GOUDHAN_CAMPAIGN_SLUG}`;
  if (moduleId === "supporter-dashboard") return "/account";
  if (action === "aiCopilot") return "/app?tab=campaigns";
  return tab ? `/app?tab=${tab}` : "";
}

export function CampaignOsLandingPage() {
  const { language } = useTranslation();
  const [activeTrack, setActiveTrack] = useState<CampaignShowcaseTrack | "all">("all");
  const pillars = campaignShowcaseTracks.filter((track) => track.id !== "businessOs");
  const capabilityModules = [...campaignShowcaseModules, ...supplementalCapabilities];
  const assessmentById = new Map(campaignCapabilityAssessments.map((assessment) => [assessment.id, assessment]));
  const visibleModules = activeTrack === "all"
    ? capabilityModules
    : capabilityModules.filter((module) => module.track === activeTrack);

  return (
    <main className="campaignos-landing">
      <header className="campaignos-nav">
        <a className="campaignos-brand" href="/" aria-label="VoiceUp Business OS home">
          <span><Megaphone size={20} /></span>
          <div><strong>CampaignOS</strong><small>by VoiceUp Business OS</small></div>
        </a>
        <nav aria-label="CampaignOS sections">
          <a href="#operating-model">Operating model</a>
          <a href="#capabilities">Capabilities</a>
          <a href="#roles">Access</a>
        </nav>
        <div className="campaignos-nav-actions">
          <LanguageSwitcher />
          <a href="/">VoiceUp <ArrowRight size={14} /></a>
        </div>
      </header>

      <section className="campaignos-hero">
        <div className="campaignos-hero-glow" aria-hidden="true" />
        <motion.div className="campaignos-hero-copy" initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.48 }}>
          <span className="campaignos-kicker"><Sparkles size={15} /> VoiceUp Business OS</span>
          <h1>CampaignOS <em>— From an Idea to a Movement.</em></h1>
          <p>Plan, launch, mobilize and prove public campaigns from one governed command system—connecting teams, supporters, field evidence, communications and growth.</p>
          <div className="campaignos-hero-actions">
            <a className="campaignos-primary" href={`/c/${GOUDHAN_CAMPAIGN_SLUG}`}>Explore Campaigns <ArrowRight size={17} /></a>
            <a href="/start">Create Campaign</a>
            <a href="/account">Supporter Account</a>
            <a href="/applications/campaign/act">Campaign Admin</a>
          </div>
          <p className="campaignos-access-note"><ShieldCheck size={15} /> Protected workspaces retain their existing identity, role, plan and campaign-scope checks.</p>
        </motion.div>
        <motion.div className="campaignos-command-visual" initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.55, delay: 0.08 }} aria-label="CampaignOS command system illustration">
          <div className="campaignos-visual-top"><span /><span /><span /><strong>CAMPAIGN COMMAND CENTER</strong></div>
          <div className="campaignos-visual-core"><Megaphone size={30} /><strong>One campaign.<br />One operating picture.</strong></div>
          <div className="campaignos-visual-orbit">
            {pillars.map((pillar, index) => {
              const Icon = pillarIcons[pillar.id];
              return <span key={pillar.id} style={{ "--orbit-index": index } as React.CSSProperties}><Icon size={16} /> {pillar.title[language]}</span>;
            })}
          </div>
          <div className="campaignos-visual-footer"><span>People</span><span>Evidence</span><span>Action</span><span>Growth</span></div>
        </motion.div>
      </section>

      <section className="campaignos-section campaignos-pillars" id="operating-model" aria-labelledby="campaignos-pillars-title">
        <div className="campaignos-section-heading">
          <span>THE OPERATING MODEL</span>
          <h2 id="campaignos-pillars-title">Every stage of movement building, connected.</h2>
          <p>The six-pillar model reflects modules already present in the CampaignOS workspace and clearly distinguishes protected or planned areas.</p>
        </div>
        <div className="campaignos-pillar-flow">
          {pillars.map((pillar, index) => {
            const Icon = pillarIcons[pillar.id];
            const destination = pillarDestinations[pillar.id];
            return (
              <article key={pillar.id}>
                <span className="campaignos-pillar-number">0{index + 1}</span>
                <span className="campaignos-pillar-icon"><Icon size={22} /></span>
                <h3>{pillar.title[language]}</h3>
                <p>{pillar.description[language]}</p>
                {destination ? <a href={destination}>Open protected module <ArrowRight size={14} /></a> : <span className="campaignos-planned-label">Planned workflows</span>}
              </article>
            );
          })}
        </div>
      </section>

      <section className="campaignos-section campaignos-capabilities" id="capabilities" aria-labelledby="campaignos-capabilities-title">
        <div className="campaignos-section-heading is-light">
          <span>EVIDENCE-BASED DIRECTORY</span>
          <h2 id="campaignos-capabilities-title">The real Command Center capability map.</h2>
          <p>{campaignShowcaseCopy.description[language]}</p>
        </div>
        <div className="campaignos-filters" role="group" aria-label="Filter capabilities by operating pillar">
          <button className={activeTrack === "all" ? "active" : ""} type="button" onClick={() => setActiveTrack("all")}>All capabilities</button>
          {campaignShowcaseTracks.map((track) => <button className={activeTrack === track.id ? "active" : ""} key={track.id} type="button" onClick={() => setActiveTrack(track.id)}>{track.title[language]}</button>)}
        </div>
        <div className="campaignos-capability-grid">
          {visibleModules.map((module, index) => {
            const actualStatus = assessmentById.get(module.id)?.actualStatus ?? module.status;
            const status = availability[actualStatus];
            const Icon = moduleIcons[module.id] ?? pillarIcons[module.track];
            const href = actualStatus === "notStarted" || actualStatus === "blocked" ? "" : moduleHref(module.id, module.tab, module.action);
            return (
              <motion.article key={module.id} initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.2 }} transition={{ delay: (index % 6) * 0.025 }}>
                <div className="campaignos-capability-top"><span><Icon size={18} /></span><b className={`campaignos-status ${status.className}`}>{status.label}</b></div>
                <small>{campaignShowcaseTracks.find((track) => track.id === module.track)?.title[language]} · {campaignReadinessLabels[actualStatus][language]}</small>
                <h3>{module.title[language]}</h3>
                <p>{module.description[language]}</p>
                {module.blockedReason && <p className="campaignos-blocked-reason">{module.blockedReason[language]}</p>}
                {href ? <a href={href}>{module.id === "gsaa-public-campaign" ? "Open public campaign" : "Enter protected workspace"} <ArrowRight size={14} /></a> : <span className="campaignos-no-action">No live entry until available</span>}
              </motion.article>
            );
          })}
        </div>
      </section>

      <section className="campaignos-section campaignos-roles" id="roles" aria-labelledby="campaignos-roles-title">
        <div className="campaignos-section-heading">
          <span>ROLE-BASED ENTRY</span>
          <h2 id="campaignos-roles-title">The right door for every participant.</h2>
          <p>Each entry uses an existing route and keeps Campaign Admin access separate from VoiceUp Platform administration.</p>
        </div>
        <div className="campaignos-role-grid">
          {[
            ["Public visitor", "Explore the live public campaign journey.", `/c/${GOUDHAN_CAMPAIGN_SLUG}`, Globe2],
            ["Supporter", "Sign in and open owner-scoped supporter access.", "/account", HeartHandshake],
            ["Campaign creator", "Start the existing guided campaign onboarding.", "/start", Sparkles],
            ["Campaign Admin", "Choose a campaign and enter its campaign-scoped admin route.", "/applications/campaign/act", Megaphone],
            ["VoiceUp Platform Admin", "Platform-owner administration only—not Campaign Admin.", "/admin", ShieldCheck]
          ].map(([title, description, href, Icon]) => {
            const RoleIcon = Icon as LucideIcon;
            return <article key={title as string}><RoleIcon size={22} /><h3>{title as string}</h3><p>{description as string}</p><a href={href as string}>Continue <ArrowRight size={14} /></a></article>;
          })}
        </div>
        <div className="campaignos-boundary"><ShieldCheck size={22} /><div><strong>Administration boundary</strong><p><code>/admin</code> remains exclusively the VoiceUp Platform Admin gate. Campaign administrators use campaign-specific <code>/admin/:slug</code> routes reached through the Campaign Admin gateway.</p></div></div>
      </section>

      <footer className="campaignos-footer"><a href="/">← VoiceUp Business OS</a><span>CampaignOS · Governed campaigns from idea to movement</span></footer>
    </main>
  );
}
