import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
const app = readFileSync(new URL("../src/App.tsx", import.meta.url), "utf8");
const page = readFileSync(new URL("../src/pages/PublicCampaignPage.tsx", import.meta.url), "utf8");
const photo = readFileSync(new URL("../src/components/PublicSupporterPhoto.tsx", import.meta.url), "utf8");
test("referral does not silently accept an unmatched input", () => {
  assert.match(app, /if \(referralInput && !referrer\)/);
  assert.doesNotMatch(app, /: normalizeReferralCode\(referralInput\)/);
});
test("self referral is rejected", () => {
  assert.match(app, /You cannot refer yourself/);
});
test("referrer identity is displayed when found", () => {
  assert.match(page, /Referring supporter: \$\{getSafeReferrerLabel\(typedReferrer\)\}/);
});
test("photo upload preserves actionable error detail", () => {
  assert.match(photo, /error instanceof Error \? error.message.trim\(\)/);
});
